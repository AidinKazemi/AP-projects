#pragma once

#include <iostream>
#include <vector>
#include <string>
#include <memory>
#include <sstream>
#include "driver.hh"
#include "missions.hh"
#include "exeptions.hh"

const std::string TIME_MISSION_INPUT = "add_time_mission";
const std::string DISTANCE_MISSION_INPUT = "add_distance_mission";
const std::string COUNT_MISSION_INPUT = "add_count_mission";
const std::string RECORD_RIDE_INPUT = "record_ride";
const std::string ASSIGN_MISSION_INPUT = "assign_mission";
const std::string SHOW_MISSION_STATUS_INPUT = "show_missions_status";
const std::string INVALID_ARGUMENT_ERROR = "INVALID_ARGUMENTS";
const std::string DUP_MISSION_ID_ERROR = "DUPLICATE_MISSION_ID";
const std::string MISSION_FINDING_ERROR = "MISSION_NOT_FOUND";
const std::string DUP_DRIVER_MISSION_ERROR = "DUPLICATE_DRIVER_MISSION";
const std::string DRIVER_HAS_NO_MISSION_ERROR = "DRIVER_MISSION_NOT_FOUND";
const std::string SUCCESSFUL_OPERATION = "OK";
const std::string INPUT_ERROR = "INPUT_ERROR";
const int ADD_MISSION_WORD_COUNT = 6;
const int MISION_STATUS_WORD_COUNT = 2;
const int ASSIGN_MISSION_WORD_COUNT = 3;
const int REDORD_RIDE_WORD_COUNT = 5;

class Data_base
{
public:
    Data_base(){}
    void handle_input();

private:
    std::vector<std::shared_ptr<Mission_information>> all_missions;
    std::vector<std::shared_ptr<Driver>> all_drivers;
    template <typename T>
    void add_mission(std::stringstream &new_input_stream);
    void match_mission_to_driver(std::stringstream &new_input_stream);
    void match_record_to_driver(std::stringstream &new_input_stream);
    void match_mission_status(std::stringstream &new_input_stream);
};
