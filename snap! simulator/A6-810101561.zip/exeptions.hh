#pragma once

#include <iostream>
#include <vector>
#include <string>
#include <memory>

class Duplicate_mission_id
{
public:
    Duplicate_mission_id(std::string a) {}
};

class Mission_not_found
{
public:
    Mission_not_found(std::string a) {}
};
class Duplicate_driver_mission
{
public:
    Duplicate_driver_mission(std::string a) {}
};
class Driver_has_no_mission
{
public:
    Driver_has_no_mission(std::string a) {}
};