#pragma once

#include <iostream>
#include <vector>
#include <string>
#include <memory>

const int SECOND_COUNTS_OF_MINUTE = 60;
const int MISSION_STILL_ONGOING = -1;
enum mission_states
{
    ONGOING,
    COMPELETED
};

class Mission_state
{
public:
    Mission_state(int init_mission_id, long long init_start_time_stamp,
                  long long init_end_time_stamp, int init_reward)
        : mission_id(init_mission_id), start_time_stamp(init_start_time_stamp),
          end_time_stamp(init_end_time_stamp), reward(init_reward) {}
    virtual bool check_if_mission_ends() = 0;
    void add_record(int start, int end, int distance, int driver_id, bool &is_the_first_mission);
    void print_mission_compeleted(int driver_id, bool &is_the_first_mission);
    void print_mission_information(int driver_id, bool &is_the_first_mission);
    int get_id() { return mission_id; }
    int get_start_time() { return start_time_stamp; }
    int get_end_time() { return end_time_stamp; }
    int get_reward() { return reward; }
    int status = ONGOING;

protected:
    int time_spent = 0;
    int distance_spent = 0;
    int count = 0;
    int mission_id;
    long long start_time_stamp;
    long long end_time_stamp;
    int reward;
};

class Time_mission_state : public Mission_state
{
public:
    Time_mission_state(int init_time, int init_mission_id, long long init_start_time_stamp,
                       long long init_end_time_stamp, int init_reward)
        : Mission_state(init_mission_id, init_start_time_stamp,
                        init_end_time_stamp, init_reward) { needed_time_in_minutes = init_time; }
    virtual bool check_if_mission_ends() { return time_spent >= needed_time_in_minutes * SECOND_COUNTS_OF_MINUTE;}

private:
    int needed_time_in_minutes;
};

class Distance_mission_state : public Mission_state
{
public:
    Distance_mission_state(int init_distance, int init_mission_id, long long init_start_time_stamp,
                           long long init_end_time_stamp, int init_reward)
        : Mission_state(init_mission_id, init_start_time_stamp,
                        init_end_time_stamp, init_reward) { needed_distance = init_distance; }
    virtual bool check_if_mission_ends() { return distance_spent >= needed_distance; }

private:
    int needed_distance;
};

class Count_mission_state : public Mission_state
{
public:
    Count_mission_state(int init_count, int init_mission_id, long long init_start_time_stamp,
                        long long init_end_time_stamp, int init_reward)
        : Mission_state(init_mission_id, init_start_time_stamp,
                        init_end_time_stamp, init_reward) { needed_count = init_count; }
    virtual bool check_if_mission_ends() { return count >= needed_count; }

private:
    int needed_count;
};

class Mission_information
{
public:
    Mission_information(int init_mission_id, long long init_start_time_stamp,
                        long long init_end_time_stamp, int init_reward);
    int get_id() { return mission_id; }
    int get_start_time() { return start_time_stamp; }
    int get_end_time() { return end_time_stamp; }
    int get_reward() { return reward; }
    virtual std::shared_ptr<Mission_state> get_new_mission_state() = 0;

protected:
    long long start_time_stamp;
    long long end_time_stamp;
    int reward;
    int mission_id;
};

class Time_mission_information : public Mission_information
{
public:
    Time_mission_information(int init_mission_id, long long init_start_time_stamp,
                             long long init_end_time_stamp, int init_reward, int init_needed_time);
    virtual std::shared_ptr<Mission_state> get_new_mission_state()
    {
        return std::make_shared<Time_mission_state>(needed_time_in_minutes, mission_id,
                                                    start_time_stamp, end_time_stamp, reward);
    }

private:
    int needed_time_in_minutes;
};

class Count_mission_information : public Mission_information
{
public:
    Count_mission_information(int init_mission_id, long long init_start_time_stamp,
                              long long init_end_time_stamp, int init_reward, int init_needed_count);
    virtual std::shared_ptr<Mission_state> get_new_mission_state()
    {
        return std::make_shared<Count_mission_state>(needed_count, mission_id,
                                                     start_time_stamp, end_time_stamp, reward);
    }

private:
    int needed_count;
};

class Distance_mission_information : public Mission_information
{
public:
    Distance_mission_information(int init_mission_id, long long init_start_time_stamp,
                                 long long init_end_time_stamp, int init_reward, int init_needed_distance);
    virtual std::shared_ptr<Mission_state> get_new_mission_state()
    {
        return std::make_shared<Distance_mission_state>(needed_distance, mission_id,
                                                        start_time_stamp, end_time_stamp, reward);
    }

private:
    int needed_distance;
};
