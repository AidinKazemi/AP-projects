#pragma once

#include <iostream>
#include <vector>
#include <string>
#include <memory>
#include <algorithm>
#include "missions.hh"
#include "exeptions.hh"

class Driver
{
public:
    Driver(int id);
    void add_mission(std::shared_ptr<Mission_information> new_mission);
    void match_record_and_missions(int start, int end, int distance);
    void show_missions_status();
    int get_driver_id() {return driver_id;}
    void sort_missions();
private:
    int driver_id;
    std::vector<std::shared_ptr<Mission_state>> missions_states;
};