#include "driver.hh"

using namespace std;

Driver::Driver(int id)
{
   driver_id = id;
}

void Driver::add_mission(std::shared_ptr<Mission_information> new_mission)
{
   for (auto &x : missions_states)
      if (x->get_id() == new_mission->get_id())
         throw Duplicate_driver_mission("");
   missions_states.push_back(new_mission->get_new_mission_state());
   sort_missions();
}

void Driver::match_record_and_missions(int start, int end, int distance)
{
   cout << "completed missions for driver " << driver_id << ":" << endl;
   bool is_the_first_mission = true;
   for (auto &x : missions_states)
      if (x->get_start_time() <= start && x->get_end_time() >= end && x->status == ONGOING)
         x->add_record(start, end, distance, driver_id, is_the_first_mission);
}

void Driver::show_missions_status()
{
   if (missions_states.size() == 0)
      throw Driver_has_no_mission("");
   bool is_the_first_mission = true;
   cout << "missions status for driver " << driver_id << ":" << endl;
   for (auto &x : missions_states)
   {
      x->print_mission_information(driver_id, is_the_first_mission);
      is_the_first_mission = false;
   }
}

bool compare(shared_ptr<Mission_state> first, shared_ptr<Mission_state> second)
{
   return first->get_start_time() <= second->get_start_time();
}

void Driver::sort_missions()
{
   sort(missions_states.begin(), missions_states.end(), compare);
}