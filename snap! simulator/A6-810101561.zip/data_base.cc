#include "data_base.hh"

using namespace std;

void check_word_counts(string new_input, int needed_count)
{
    stringstream inp_stream(new_input);
    string junk;
    int word_count = 0;
    while (getline(inp_stream, junk, ' '))
        word_count++;
    if (word_count != needed_count)
        throw invalid_argument("");
}

void Data_base::handle_input()
{
    string new_input, first_word;
    while (getline(cin, new_input))
    {
        stringstream new_input_stream(new_input);
        new_input_stream >> first_word;
        try
        {
            if (first_word == TIME_MISSION_INPUT)
            {
                check_word_counts(new_input, ADD_MISSION_WORD_COUNT);
                add_mission<Time_mission_information>(new_input_stream);
            }
            else if (first_word == DISTANCE_MISSION_INPUT)
            {
                check_word_counts(new_input, ADD_MISSION_WORD_COUNT);
                add_mission<Distance_mission_information>(new_input_stream);
            }
            else if (first_word == COUNT_MISSION_INPUT)
            {
                check_word_counts(new_input, ADD_MISSION_WORD_COUNT);
                add_mission<Count_mission_information>(new_input_stream);
            }
            else if (first_word == ASSIGN_MISSION_INPUT)
            {
                check_word_counts(new_input, ASSIGN_MISSION_WORD_COUNT);
                match_mission_to_driver(new_input_stream);
            }
            else if (first_word == RECORD_RIDE_INPUT)
            {
                check_word_counts(new_input, REDORD_RIDE_WORD_COUNT);
                match_record_to_driver(new_input_stream);
            }
            else if (first_word == SHOW_MISSION_STATUS_INPUT)
            {
                check_word_counts(new_input, MISION_STATUS_WORD_COUNT);
                match_mission_status(new_input_stream);
            }
            else
                cout << INPUT_ERROR << endl;
        }

        catch (invalid_argument &a)
        {
            cout << INVALID_ARGUMENT_ERROR << endl;
        }
        catch (Duplicate_mission_id &a)
        {
            cout << DUP_MISSION_ID_ERROR << endl;
        }
        catch (Mission_not_found &a)
        {
            cout << MISSION_FINDING_ERROR << endl;
        }
        catch (Duplicate_driver_mission &a)
        {
            cout << DUP_DRIVER_MISSION_ERROR << endl;
        }
        catch (Driver_has_no_mission &a)
        {
            cout << DRIVER_HAS_NO_MISSION_ERROR << endl;
        }
    }
}

template <typename T>
void Data_base::add_mission(stringstream &new_input_stream)
{
    int mission_id, start_time_stamp, end_time_stamp, reward, mission_dependancy;
    new_input_stream >> mission_id >> start_time_stamp >> end_time_stamp >> mission_dependancy >> reward;
    shared_ptr<T> new_T = make_shared<T>(mission_id, start_time_stamp, end_time_stamp, reward, mission_dependancy);
    for (auto &x : all_missions)
        if (x->get_id() == mission_id)
            throw Duplicate_mission_id("");
    all_missions.push_back(new_T);
    cout << SUCCESSFUL_OPERATION << endl;
}

void Data_base::match_mission_to_driver(stringstream &new_input_stream)
{
    int driver_id, mission_id;
    new_input_stream >> mission_id >> driver_id;
    bool mission_not_found = true;
    shared_ptr<Mission_information> needed_mission;
    for (auto &x : all_missions)
        if (x->get_id() == mission_id)
        {
            mission_not_found = false;
            needed_mission = x;
        }

    if (mission_not_found)
        throw Mission_not_found("");

    bool driver_exists = false;
    shared_ptr<Driver> needed_driver = make_shared<Driver>(driver_id);
    for (auto &x : all_drivers)
        if (x->get_driver_id() == driver_id)
        {
            needed_driver.reset();
            driver_exists = true;
            needed_driver = x;
        }
    if (!driver_exists)
        all_drivers.push_back(needed_driver);

    needed_driver->add_mission(needed_mission);
    cout << SUCCESSFUL_OPERATION << endl;
}

void Data_base::match_record_to_driver(stringstream &new_input_stream)
{
    int start_time, end_time, distance, id;
    new_input_stream >> start_time >> end_time >> id >> distance;
    if (start_time > end_time)
        throw invalid_argument("");

    for (auto &x : all_drivers)
        if (x->get_driver_id() == id)
        {
            x->match_record_and_missions(start_time, end_time, distance);
            return;
        }
    throw Mission_not_found("");
}

void Data_base::match_mission_status(stringstream &new_input_stream)
{
    int id;
    new_input_stream >> id;

    for (auto &x : all_drivers)
        if (x->get_driver_id() == id)
        {
            x->show_missions_status();
            return;
        }
    throw Mission_not_found("");
}
