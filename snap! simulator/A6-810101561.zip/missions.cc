#include <iostream>
#include <vector>
#include <string>
#include <memory>
#include "missions.hh"

using namespace std;

Mission_information::Mission_information(int init_mission_id, long long init_start_time_stamp,
                                         long long init_end_time_stamp, int init_reward)
{
    mission_id = init_mission_id;
    start_time_stamp = init_start_time_stamp;
    end_time_stamp = init_end_time_stamp;
    reward = init_reward;
}

Time_mission_information::Time_mission_information(int init_mission_id, long long init_start_time_stamp,
                                                   long long init_end_time_stamp, int init_reward, int init_needed_time)
    : Mission_information(init_mission_id, init_start_time_stamp, init_end_time_stamp, init_reward)
{
    if (init_start_time_stamp > init_end_time_stamp || init_reward < 0 || init_mission_id < 0 || init_needed_time < 0)
        throw invalid_argument("");
    needed_time_in_minutes = init_needed_time;
}

Distance_mission_information::Distance_mission_information(int init_mission_id, long long init_start_time_stamp,
                                                           long long init_end_time_stamp, int init_reward, int init_needed_distance)
    : Mission_information(init_mission_id, init_start_time_stamp, init_end_time_stamp, init_reward)
{
    if (init_start_time_stamp > init_end_time_stamp || init_reward < 0 || init_mission_id < 0 || init_needed_distance < 0)
        throw invalid_argument("");
    needed_distance = init_needed_distance;
}

Count_mission_information::Count_mission_information(int init_mission_id, long long init_start_time_stamp,
                                                     long long init_end_time_stamp, int init_reward, int init_needed_count)
    : Mission_information(init_mission_id, init_start_time_stamp, init_end_time_stamp, init_reward)
{
    if (init_start_time_stamp > init_end_time_stamp || init_reward < 0 || init_mission_id < 0 || init_needed_count < 0)
        throw invalid_argument("");
    needed_count = init_needed_count;
}

void Mission_state::print_mission_compeleted(int driver_id, bool &is_the_first_mission)
{
    if (is_the_first_mission == false)
        cout << endl;
    cout << "mission: " << mission_id << endl
         << "start timestamp: " << start_time_stamp << endl
         << "end timestamp: " << end_time_stamp << endl
         << "reward: " << reward << endl;
}

void Mission_state::add_record(int start, int end, int distance, int driver_id, bool &is_the_first_mission)
{
    time_spent += (end - start);
    distance_spent += distance;
    count++;
    if (check_if_mission_ends())
    {
        status = COMPELETED;
        end_time_stamp = end;
        print_mission_compeleted(driver_id, is_the_first_mission);
        is_the_first_mission = false;
    }
}

void Mission_state::print_mission_information(int driver_id, bool &is_the_first_mission)
{
    if (is_the_first_mission == false)
        cout << endl;
    cout << "mission: " << mission_id << endl
         << "start timestamp: " << start_time_stamp << endl;
    if (status == ONGOING)
    {
        cout << "end timestamp: " << MISSION_STILL_ONGOING << endl
             << "reward: " << reward << endl
             << "status: ongoing" << endl;
    }
    else
    {
        cout << "end timestamp: " << end_time_stamp << endl
             << "reward: " << reward << endl
             << "status: completed" << endl;
    }
}
