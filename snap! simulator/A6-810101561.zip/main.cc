#include <iostream>
#include <vector>
#include <string>
#include <memory>
#include <sstream>
#include "driver.hh"
#include "missions.hh"
#include "data_base.hh"

using namespace std;

int main()
{
    Data_base new_data_base;
    new_data_base.handle_input();
    return 0;
}