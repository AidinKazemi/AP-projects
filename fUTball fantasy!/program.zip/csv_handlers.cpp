#include "Data_base.hpp"

using namespace std;

void Data_base::read_csv_premier_league()
{
    fstream premier_league(PREMIER_LEAGUE_CSV);
    if (!premier_league)
        cout << "opening premier league faild" << endl;
    string new_line;
    getline(premier_league, new_line);
    for (; getline(premier_league, new_line);)
        all_teams.push_back(read_team_line_csv(new_line));
    premier_league.close();
}
shared_ptr<Team> Data_base::read_team_line_csv(string new_line)
{
    map<int, vector<shared_ptr<Player>>> team_players;
    stringstream new_line_stream(new_line);
    string players_info;
    string team_name;
    getline(new_line_stream, team_name, ',');
    for (int post = GOALKEEPER; getline(new_line_stream, players_info, ','); post++)
    {
        vector<shared_ptr<Player>> same_posts = handle_players_info(post, players_info);
        team_players.insert(std::pair<int, vector<shared_ptr<Player>>>(post, same_posts));
        all_players.insert(all_players.end(), same_posts.begin(), same_posts.end());
    }
    shared_ptr<Team> new_team = make_shared<Team>(team_name, team_players);
    return new_team;
}
vector<shared_ptr<Player>> Data_base::handle_players_info(int post, string players_info)
{
    vector<shared_ptr<Player>> same_posts;
    stringstream players_info_stream(players_info);
    string new_player_info;
    for (; getline(players_info_stream, new_player_info, ';');)
    {
        if (new_player_info.find('\r') != string::npos)
            new_player_info.erase(new_player_info.find('\r'));
        pair<string, string> name_and_price =
            seprate_string_by_doublecolon(new_player_info);
        if (name_and_price.second.find('$') != string::npos)
            name_and_price.second.erase(name_and_price.second.find('$'));
        shared_ptr<Player> new_player = Player::get_post_specified_player(post, name_and_price.first, stoi(name_and_price.second));
        same_posts.push_back(new_player);
    }
    return same_posts;
}

string &operator+(string week, int num)
{
    return week.insert(week.find('.'), to_string(num));
}

void Data_base::read_weeks_csv()
{
    for (int week_num = FIRST_WEEK; week_num <= WEEK_COUNTS; week_num++)
        all_weeks.push_back(read_special_week(week_num));
}
Week Data_base::read_special_week(int week_num)
{
    Week new_week;
    fstream new_week_stream(WEEK_CSV + week_num);
    if (!new_week_stream)
        cout << "opening week " + to_string(week_num) << " faild" << endl;
    string new_line;
    getline(new_week_stream, new_line);
    for (; getline(new_week_stream, new_line);)
        new_week.push_back(handle_match(new_line));
    new_week_stream.close();
    return new_week;
}
shared_ptr<Match> Data_base::handle_match(string new_line)
{
    vector<string> _match_information;
    stringstream new_line_stream(new_line);
    string word;
    for (; getline(new_line_stream, word, ',');)
        _match_information.push_back(word);
    shared_ptr<Match> new_match = make_the_match(_match_information);
    return new_match;
}
shared_ptr<Match> Data_base::make_the_match(vector<string> _match_information)
{
    shared_ptr<Match> new_match = make_shared<Match>(seprate_string_by_doublecolon(_match_information[MATCH]));
    new_match->set_result(seprate_string_by_doublecolon(_match_information[RESULT]));
    new_match->add_injureds(_match_information[INJURED]);
    new_match->add_yellow_cards(_match_information[YELLOW_CARD]);
    new_match->add_red_cards(_match_information[RED_CARD]);
    new_match->add_goals_and_assists(_match_information[GOALS_WITH_ASSISTS]);
    new_match->add_match_players(vector<string>(&_match_information[HOME_TEAM_PLAYERS],
                                                &_match_information[_match_information.size()]));

    return new_match;
}