#include "classes.hpp"

using namespace std;

Player::Player(string _name, int _price)
{
    name = _name;
    price = _price;
}
string Player::get_name()
{
    return name;
}
float Player::get_score()
{
    return score;
}
float Player::get_avg_score()
{
    if (games_count == 0)
        return 0;
    return all_scores / games_count;
}
int Player::get_price()
{
    return price;
}
bool Player::are_you(string _name)
{
    return name == _name;
}
bool Player::are_you_available()
{
    return suspension != MISSED_NEXT_WEEK && injury == OK;
}
void Player::pass_week_for_player()
{
    if (injury == INJURED3)
        injury = OK;
    if (injury == INJURED2)
        injury = INJURED3;
    if (injury == INJURED1)
        injury = INJURED2;
    if (injury == GET_INJURED)
        injury = INJURED1;

    if (suspension == MISSED_NEXT_WEEK)
        suspension = FREE;
    if (suspension == RED)
        suspension = MISSED_NEXT_WEEK;
    if (score != 0)
        games_count++;
    all_scores += score;
}
void Player::injure()
{
    injury = GET_INJURED;
}
void Player::get_yellow_card()
{
    suspension++;
}
void Player::get_red_card()
{
    suspension = RED;
}
void Player::print_with_score()
{
    cout << fixed << setprecision(1);
    cout << name << " | score: " << score << endl;
}
void Player::reset_score()
{
    score = 0;
}

int Goalkeeper::get_position()
{
    return GOALKEEPER;
}
void Goalkeeper::print_with_role()
{
    cout << fixed << setprecision(1);
    cout << "name: " << name << " | role: gk | score: " << get_avg_score() << " | cost: " << price
         << " | clean sheets: " << all_clean_sheets << endl;
}
void Goalkeeper::set_score(int match_result, int clean_sheet, int goals_concede, int goals, int assits, int own_goals)
{
    int point = 3;
    if (match_result == WIN)
        point += 5;
    else if (match_result == DRAW)
        point += 1;
    else
        point -= 1;
    point -= (3 * own_goals);
    point -= goals_concede;
    if (clean_sheet)
    {
        point += 5;
        all_clean_sheets++;
    }
    raw_score = point;
    score = calculate_score(point);
}

int Defender::get_position()
{
    return DEFENDER;
}
void Defender::print_with_role()
{
    cout << fixed << setprecision(1);
    cout << "name: " << name << " | role: df | score: " << get_avg_score() << " | cost: " << price << " | goals: "
         << all_goals << " | assists: " << all_assists << " | clean sheets: " << all_clean_sheets << endl;
}
void Defender::set_score(int match_result, int clean_sheet, int goals_concede, int goals, int assits, int own_goals)
{
    int point = 1;
    if (match_result == WIN)
        point += 5;
    else if (match_result == DRAW)
        point += 1;
    else
        point -= 1;
    point -= (3 * own_goals);
    point += (4 * goals);
    point += (3 * assits);
    point -= goals_concede;
    if (clean_sheet)
    {
        point += 2;
        all_clean_sheets++;
    }
    all_goals += goals;
    all_assists += assits;
    raw_score = point;
    score = calculate_score(point);
}

int Midfielder::get_position()
{
    return MIDFIELDER;
}
void Midfielder::print_with_role()
{
    cout << fixed << setprecision(1);
    cout << "name: " << name << " | role: md | score: " << get_avg_score() << " | cost: " << price << " | goals: "
         << all_goals << " | assists: " << all_assists << " | clean sheets: " << all_clean_sheets << endl;
}
void Midfielder::set_score(int match_result, int clean_sheet, int goals_concede, int goals, int assits, int own_goals)
{
    int point = 0;
    if (match_result == WIN)
        point += 5;
    else if (match_result == DRAW)
        point += 1;
    else
        point -= 1;
    point -= (3 * own_goals);
    point += (3 * goals);
    point += (2 * assits);
    point -= goals_concede;
    if (clean_sheet)
    {
        point += 1;
        all_clean_sheets++;
    }
    all_goals += goals;
    all_assists += assits;
    raw_score = point;
    score = calculate_score(point);
}

int Forward::get_position()
{
    return FORWARD;
}
void Forward::print_with_role()
{
    cout << fixed << setprecision(1);
    cout << "name: " << name << " | role: fw | score: " << get_avg_score() << " | cost: " << price << " | goals: "
         << all_goals << " | assists: " << all_assists << endl;
}
void Forward::set_score(int match_result, int clean_sheet, int goals_concede, int goals, int assits, int own_goals)
{
    int point = 0;
    if (match_result == WIN)
        point += 5;
    else if (match_result == DRAW)
        point += 1;
    else
        point -= 1;
    point -= (3 * own_goals);
    point += (3 * goals);
    point += (2 * assits);
    if (goals == 0)
        point -= 1;
    all_goals += goals;
    all_assists += assits;
    raw_score = point;
    score = calculate_score(point);
}

Team::Team(string _name, map<int, vector<shared_ptr<Player>>> _team_players)
{
    name = _name;
    team_players = _team_players;
}

void Team::add_result(int gf, int ga)
{
    goals_for += gf;
    goals_against += ga;
    if (gf > ga)
        score += 3;
    else if (gf == ga)
        score++;
}
bool Team::are_you(string _name)
{
    return name == _name;
}
void Team::print()
{
    cout << name << ": score: " << score << " | GF: " << goals_for << " | GA: " << goals_against << endl;
}

Match::Match(std::pair<std::string, std::string> teams)
{
    home_team = teams.first;
    away_team = teams.second;
}
void Match::set_result(std::pair<std::string, std::string> goals)
{
    home_goals = stoi(goals.first);
    away_goals = stoi(goals.second);
}
void Match::add_injureds(string info)
{
    injures = seprate_string_by_semicolon(info);
}
void Match::add_yellow_cards(string info)
{
    yellow_cards = seprate_string_by_semicolon(info);
}
void Match::add_red_cards(string info)
{
    red_cards = seprate_string_by_semicolon(info);
}
void Match::add_goals_and_assists(std::string info)
{
    vector<string> gs_and_as = seprate_string_by_semicolon(info);
    for (auto x : gs_and_as)
    {
        pair<string, string> scorer_and_assistant = seprate_string_by_doublecolon(x);
        if (scorer_and_assistant.second == "OWN_GOAL")
            own_goals.push_back(scorer_and_assistant.first);
        else
        {
            goals.push_back(scorer_and_assistant.first);
            assists.push_back(scorer_and_assistant.second);
        }
    }
}

void Match::add_match_players(std::vector<std::string> info)
{
    string player_name;
    for (int i = 0; i < info.size(); i++)
    {
        stringstream info_stream(info[i]);
        match_players.push_back(vector<string>(0));
        for (; getline(info_stream, player_name, ';');)
            match_players[i].push_back(player_name);
    }
}
void Match::make_changes_for_player(vector<std::shared_ptr<Player>> players, int side, int post)
{
    shared_ptr<Player> needed_player = find_something(players, match_players[side][post]);
    string needed_player_name = match_players[side][post];
    int g = how_many_repetition(goals, needed_player_name);
    int a = how_many_repetition(assists, needed_player_name);
    int og = how_many_repetition(own_goals, needed_player_name);
    int mr;
    int cs = 0;
    int gc = 0;
    if (side == HOME)
    {
        mr = calculate_result(home_goals, away_goals);
        if (away_goals == 0)
            cs++;
        gc = calculate_goals_concede(AWAY, post, away_goals);
    }
    else
    {
        mr = calculate_result(away_goals, home_goals);
        if (home_goals == 0)
            cs++;
        gc = calculate_goals_concede(HOME, post, home_goals);
    }
    needed_player->set_score(mr, cs, gc, g, a, og);
    players_scores.push_back(pair<string, float>(needed_player_name, needed_player->get_score()));
}
void Match::make_changes(vector<std::shared_ptr<Team>> teams, vector<std::shared_ptr<Player>> players)
{
    find_something(teams, home_team)->add_result(home_goals, away_goals);
    find_something(teams, away_team)->add_result(away_goals, home_goals);
    for (auto n : injures)
        find_something(players, n)->injure();
    for (auto n : yellow_cards)
        find_something(players, n)->get_yellow_card();
    for (auto n : red_cards)
        find_something(players, n)->get_red_card();
    int home_result = calculate_result(home_goals, away_goals);
    int away_result = calculate_result(away_goals, home_goals);
    for (int i = HOME; i <= AWAY; i++)
        for (int j = GK; j <= RW; j++)
            make_changes_for_player(players, i, j);
}
int Match::calculate_goals_concede(int side, int post, int away_goals)
{
    int gc = 0;
    if (post == GK)
        gc = away_goals;
    else if (post == LB)
        gc = how_many_repetition(goals, match_players[side][RB]) +
             how_many_repetition(goals, match_players[side][RW]);
    else if (LCB <= post && post <= RCB)
        gc = how_many_repetition(goals, match_players[side][LCB]) +
             how_many_repetition(goals, match_players[side][RCB]) +
             how_many_repetition(goals, match_players[side][ST]);
    else if (post == RB)
        gc = how_many_repetition(goals, match_players[side][LB]) +
             how_many_repetition(goals, match_players[side][LW]);
    else if (LMF <= post && post <= RMF)
        gc = how_many_repetition(goals, match_players[side][LMF]) +
             how_many_repetition(goals, match_players[side][CMF]) +
             how_many_repetition(goals, match_players[side][RMF]);
    return gc;
}
void Match::print()
{
    cout << home_team << " " << home_goals << " | " << away_team << " " << away_goals << endl;
}

void Fantasy_team::reset_transfer_counter()
{
    buy_transfer_counter = 0;
    sell_transfer_counter = 0;
}
bool Fantasy_team::is_complete(std::map<int, std::vector<std::shared_ptr<Player>>> f_team_players)
{
    for (auto x : f_team_players)
        for (auto y : x.second)
            if (y == NULL)
                return false;
    return true;
}
void Fantasy_team::add_score()
{
    if (this->is_complete(fantasy_team_players))
    {
        for (auto x : fantasy_team_players)
            for (auto y : x.second)
                if (captain == y)
                    total_scores += calculate_score(2 * y->get_raw_score());
                else
                    total_scores += y->get_score();
    }
}
void Fantasy_team::delete_player(std::shared_ptr<Player> player)
{
    if (sell_transfer_counter >= TRANSFER_LIMIT && user_status == OLDTMIER)
        throw My_exeption(PERMISSION_DENIED);
    for (auto &x : fantasy_team_players)
        for (auto &y : x.second)
            if (y == player)
            {
                if (captain == player)
                    captain = NULL;
                y = NULL;
                budget += player->get_price();
                sell_transfer_counter++;
                return;
            }
    throw My_exeption(NOT_FOUND);
}
void Fantasy_team::add_player(std::shared_ptr<Player> player)
{
    if (buy_transfer_counter >= TRANSFER_LIMIT && user_status == OLDTMIER)
        throw My_exeption(PERMISSION_DENIED);
    for (auto &y : fantasy_team_players.at(player->get_position()))
    {
        if (y == player)
            throw My_exeption(BAD_REQUEST);
        else if (y == NULL)
        {
            y = player;
            budget -= player->get_price();
            buy_transfer_counter++;
            return;
        }
    }
    throw My_exeption(BAD_REQUEST);
}
void Fantasy_team::set_captain(std::shared_ptr<Player> player)
{
    for (auto x : fantasy_team_players)
        for (auto y : x.second)
            if (y == player)
            {
                captain = player;
                return;
            }
    throw My_exeption(NOT_FOUND);
}
void Fantasy_team::pass_week_for_ft()
{
    last_captain = captain;
    last_week_fantasy_team_players = fantasy_team_players;
    if (user_status == NEWCOMER && is_complete(fantasy_team_players))
        user_status = OLDTMIER;
    if (user_status == OLDTMIER && is_complete(fantasy_team_players))
        add_score();
    reset_transfer_counter();
}
int Fantasy_team::calculate_total_cost(std::map<int, std::vector<std::shared_ptr<Player>>> f_team_players)
{
    int total_cost = 0;
    for (auto x : f_team_players)
        for (auto y : x.second)
            total_cost += y->get_price();
    return total_cost;
}
void Fantasy_team::print_user_team_style()
{
    if (this->is_complete(last_week_fantasy_team_players))
    {
        sort(last_week_fantasy_team_players.at(DEFENDER).begin(),
             last_week_fantasy_team_players.at(DEFENDER).end(), compare_two_players_by_name);
        cout << fixed << setprecision(1);
        cout << "fantasy_team: " << user->name << endl;
        int i = 0;
        for (auto x : last_week_fantasy_team_players)
            for (auto y : x.second)
            {
                cout << print_post_map_u_team.at(i) << y->get_name();
                if (last_captain == y)
                    cout << " (CAPTAIN)";
                cout << endl;
                i++;
            }
        cout << "Total Points: " << total_scores << endl;
        cout << "Team Cost: " << calculate_total_cost(last_week_fantasy_team_players) << endl;
    }
    else
        throw My_exeption(EMPTY);
}
void Fantasy_team::print_team_of_the_week_style()
{
    sort(fantasy_team_players.at(DEFENDER).begin(),
         fantasy_team_players.at(DEFENDER).end(), compare_two_players_by_name);
    cout << fixed << setprecision(1);
    cout << "team of the week:" << endl;
    int i = 0;
    for (auto x : fantasy_team_players)
        for (auto y : x.second)
        {
            cout << print_post_map_f_team.at(i) << y->get_name() << " | score: " << y->get_score() << endl;
            i++;
        }
}

float Fantasy_team::get_score()
{
    return total_scores;
}

template <typename T, typename S>
T find_something(std::vector<T> arr, S s)
{
    for (auto x : arr)
        if (x->are_you(s))
            return x;
    return NULL;
}

std::vector<std::string> seprate_string_by_semicolon(std::string s)
{
    std::vector<std::string> sep;
    if (s.size() == 0)
        return sep;
    std::stringstream ss(s);
    std::string contain;
    while (getline(ss, contain, ';'))
        sep.push_back(contain);
    return sep;
}

std::pair<std::string, std::string> seprate_string_by_doublecolon(std::string s)
{
    std::pair<std::string, std::string> sep;
    if (s.size() == 0)
        return sep;
    int sep_pos = s.find(':');
    sep.first = s.substr(0, sep_pos);
    sep.second = s.substr(sep_pos + 1);
    return sep;
}

Account::Account(std::string _name, std::string _password, int _role)
{
    name = _name;
    password = _password;
    role = _role;
    if (role == USER)
        user_team = make_shared<Fantasy_team>(this);
}

void Team::print_a_group_of_players(std::vector<std::shared_ptr<Player>> p)
{
    for (int i = 0; i < p.size(); i++)
    {
        cout << i + 1 << ". ";
        p[i]->print_with_role();
    }
}
bool Account::are_you(string _name)
{
    return name == _name;
}
bool Account::is_password_correct(string _password)
{
    return password == _password;
}
void Account::print()
{
    cout << fixed << setprecision(1);
    cout << "team_name: " << name << " | point: " << user_team->total_scores << endl;
}
std::shared_ptr<Player> Player::get_post_specified_player(int position, string _name, int _price)
{
    std::shared_ptr<Player> new_player;
    if (position == GOALKEEPER)
        new_player = make_shared<Goalkeeper>(_name, _price);
    else if (position == DEFENDER)
        new_player = make_shared<Defender>(_name, _price);
    else if (position == MIDFIELDER)
        new_player = make_shared<Midfielder>(_name, _price);
    else if (position == FORWARD)
        new_player = make_shared<Forward>(_name, _price);
    return new_player;
}
int how_many_repetition(std::vector<std::string> names, std::string name)
{
    int repetition = 0;
    for (auto s : names)
        if (s == name)
            repetition++;
    return repetition;
}
int calculate_result(int goals_for, int goals_concede)
{
    if (goals_for > goals_concede)
        return WIN;
    else if (goals_for == goals_concede)
        return DRAW;
    else
        return LOSE;
}
float calculate_score(int point)
{
    return 10.0 / (1 + exp((-point) / 6.0));
}
bool compare_two_players_by_name(std::shared_ptr<Player> a, std::shared_ptr<Player> b)
{
    return a->get_name().compare(b->get_name()) < 0;
}