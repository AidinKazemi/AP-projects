#pragma once

#include "classes.hpp"
#include "const_values.hpp"

class Data_base
{
public:
    Data_base()
    {
        read_csv_premier_league();
        read_weeks_csv();
    }
    void read_csv_premier_league();
    void make_action(std::string new_line);

private:
    void read_weeks_csv();
    void team_of_the_week(const std::string &command_args);
    void players(const std::string &command_args);
    void league_standings(const std::string &command_args);
    void users_ranking(const std::string &command_args);
    void matches_result_league(const std::string &command_args);
    void squad(const std::string &command_args);
    void close_transfer_window(const std::string &command_args);
    void open_transfer_window(const std::string &command_args);
    void pass_week(const std::string &command_args);
    void signup(const std::string &command_args);
    void login(const std::string &command_args);
    void register_admin(const std::string &command_args);
    void logout(const std::string &command_args);
    void sell_player(const std::string &command_args);
    void buy_player(const std::string &command_args);
    void set_captain(const std::string &command_args);
    void show_budget(const std::string &command_args);
    std::vector<std::pair<std::string, float>> get_sorted_score_list(const Week &_week);
    Fantasy_team make_team_of_the_week(std::vector<std::pair<std::string, float>> sorted_scores);
    std::shared_ptr<Team> read_team_line_csv(std::string new_line);
    std::vector<std::shared_ptr<Player>> handle_players_info(int, std::string);
    Week read_special_week(int);
    std::shared_ptr<Match> handle_match(std::string);
    std::shared_ptr<Match> make_the_match(std::vector<std::string> match_information);
    std::vector<std::shared_ptr<Team>> all_teams;
    std::vector<std::shared_ptr<Player>> all_players;
    std::vector<Week> all_weeks;
    std::vector<std::shared_ptr<Account>> all_accounts;
    std::shared_ptr<Account> current_account = NULL;
    int current_week = 0;
    Transfer_window_status transfer_window_status = OPEN;
    std::shared_ptr<Account> Admin = std::make_shared<Account>("admin", "123456", ADMIN);
};

const std::map<std::string, int> pos_str_to_int = {
    {"gk", GOALKEEPER},
    {"df", DEFENDER},
    {"md", MIDFIELDER},
    {"fw", FORWARD}};

std::pair<std::string, std::string> seprate_by_question_mark(std::string s);
std::vector<std::string> seprate_string_by_delim(std::string);
bool compare_name_score(std::pair<std::string, float> a, std::pair<std::string, float> b);
void replace_dash_with_space(std::string &s);
template <typename T, typename P>
std::vector<T> turn_map_to_vector(std::map<P, std::vector<T>> m);
bool compare_teams_for_standing(std::shared_ptr<Team> a, std::shared_ptr<Team> b);
bool compare_users_by_score(std::shared_ptr<Account> a, std::shared_ptr<Account> b);
bool compare_player_name(std::shared_ptr<Player> a, std::shared_ptr<Player> b);
bool check_start_of_command(std::string first_command);
std::string make_pure_string(std::string s);
std::string make_string_from_vector(std::vector<std::string> all_s);
bool compare_player_avg_score(std::shared_ptr<Player> a, std::shared_ptr<Player> b);
