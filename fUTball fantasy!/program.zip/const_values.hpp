#pragma once

#include <iostream>
#include <vector>
#include <string>
#include <memory>
#include <sstream>
#include <compare>
#include <map>
#include <fstream>
#include <algorithm>
#include <iomanip>
#include <math.h>
const std::string PREMIER_LEAGUE_CSV = "data/premier_league.csv";
const std::string WEEK_CSV = "data/weeks_stats/week_.csv";
const int WEEK_COUNTS = 19;
const int FIRST_WEEK = 1;
const std::string GET_TOTW = "GET team_of_the_week";
const std::string GET_PLAYERS = "GET players";
const std::string GET_LEAGUE_STANDINGS = "GET league_standings";
const std::string GET_USERS_RANKINGS = "GET users_ranking";
const std::string GET_MATCHES_RESULT_LEAGUE = "GET matches_result_league";
const std::string GET_SQUAD = "GET squad";
const std::string GET_SHOW_BUDGET = "GET show_budget";
const std::string POST_SIGNUP = "POST signup";
const std::string POST_LOGIN = "POST login";
const std::string POST_REGISTER_ADMIN = "POST register_admin";
const std::string POST_LOGOUT = "POST logout";
const std::string POST_SELL_PLAYER = "POST sell_player";
const std::string POST_BUY_PLAYER = "POST buy_player";
const std::string POST_CLOSE_TRANSFER_WINDOW = "POST close_transfer_window";
const std::string POST_OPEN_TRANSFER_WINDOW = "POST open_transfer_window";
const std::string POST_PASS_WEEK = "POST pass_week";
const std::string POST_SET_CAPTAIN = "POST set_captain";
const std::string RANKS_ORDER = "ranks";
const std::string BAD_REQUEST = "Bad Request";
const std::string NOT_FOUND = "Not Found";
const std::string PERMISSION_DENIED = "Permission Denied";
const std::string SUCCESSFUL = "OK";
const std::string EMPTY = "Empty";
const std::string JUNK = "#jUnkkl,s;dfjl;skdfijasld";
const int TRANSFER_LIMIT = 2;
const int INITIAL_BUDGET = 2500;
const int JUNK_NUM = -1;

enum Match_result
{
    LOSE,
    DRAW,
    WIN
};
enum Side
{
    HOME,
    AWAY
};
enum Position_in_f_team
{
    f_GOALKEEPER,
    f_DEFENDER1,
    f_DEFENDER2,
    f_MIDFIELDER,
    f_FORWARD
};
const std::map<int, std::string> print_post_map_u_team =
    {
        {f_GOALKEEPER, "GoalKeeper: "},
        {f_DEFENDER1, "Defender1: "},
        {f_DEFENDER2, "Defender2: "},
        {f_MIDFIELDER, "Midfielder: "},
        {f_FORWARD, "Striker: "}};

const std::map<int, std::string> print_post_map_f_team =
    {
        {f_GOALKEEPER, "GoalKeeper: "},
        {f_DEFENDER1, "Defender 1: "},
        {f_DEFENDER2, "Defender 2: "},
        {f_MIDFIELDER, "Midfielder: "},
        {f_FORWARD, "Forward: "}};

enum Position
{
    GOALKEEPER,
    DEFENDER,
    MIDFIELDER,
    FORWARD
};
enum Exact_positions
{
    GK,
    LB,
    LCB,
    RCB,
    RB,
    LMF,
    CMF,
    RMF,
    LW,
    ST,
    RW
};
enum Suspension_status
{
    FREE,
    YELLOW1,
    YELLOW2,
    RED,
    MISSED_NEXT_WEEK
};
enum Injury_status
{
    OK,
    GET_INJURED,
    INJURED1,
    INJURED2,
    INJURED3
};
enum User_role
{
    USER,
    ADMIN
};
enum User_status
{
    NEWCOMER,
    OLDTMIER
};
enum Transfer_window_status
{
    OPEN,
    CLOSE
};

enum Match_information
{
    MATCH,
    RESULT,
    INJURED,
    YELLOW_CARD,
    RED_CARD,
    GOALS_WITH_ASSISTS,
    HOME_TEAM_PLAYERS,
    AWAY_TEAM_PLAYERS
};