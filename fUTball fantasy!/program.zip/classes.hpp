#pragma once

#include "const_values.hpp"

class Player
{
public:
    std::string get_name();
    float get_score();
    float get_raw_score() { return raw_score; }
    float get_avg_score();
    int get_price();
    bool are_you(std::string _name);
    void pass_week_for_player();
    void injure();
    void get_yellow_card();
    void get_red_card();
    void print_with_score();
    bool are_you_available();
    void reset_score();
    void set_direct_score(float _score) { score = _score; }
    virtual int get_position() = 0;
    virtual void set_score(int match_result, int clean_sheet, int goals_concede, int goals, int assits,
                           int own_goals) = 0;
    virtual void print_with_role() = 0;
    static std::shared_ptr<Player> get_post_specified_player(int position, std::string _name, int _price);

protected:
    Player(std::string _name, int _price);
    std::string name;
    float score = 0;
    int suspension = FREE;
    int injury = OK;
    float all_scores = 0;
    int games_count = 0;
    int price = 0;
    int all_goals = 0;
    int all_assists = 0;
    float raw_score = 0;
    int all_clean_sheets = 0;
};

class Goalkeeper : public Player
{
public:
    Goalkeeper(std::string _name, int _price) : Player(_name, _price) {}
    int get_position();
    void print_with_role();
    void set_score(int, int, int, int, int, int);
};
class Defender : public Player
{
public:
    Defender(std::string _name, int _price) : Player(_name, _price) {}
    int get_position();
    void print_with_role();
    void set_score(int, int, int, int, int, int);
};
class Midfielder : public Player
{
public:
    Midfielder(std::string _name, int _price) : Player(_name, _price) {}
    int get_position();
    void print_with_role();
    void set_score(int, int, int, int, int, int);
};
class Forward : public Player
{
public:
    Forward(std::string _name, int _price) : Player(_name, _price) {}
    int get_position();
    void print_with_role();
    void set_score(int, int, int, int, int, int);
};

class Team
{
public:
    Team(std::string _name, std::map<int, std::vector<std::shared_ptr<Player>>>);
    void add_result(int gf, int ga);
    bool are_you(std::string _name);
    std::string get_name() { return name; }
    void print();
    std::map<int, std::vector<std::shared_ptr<Player>>> get_team_members() { return team_players; }
    void print_a_group_of_players(std::vector<std::shared_ptr<Player>> same_posts);
    int get_score() { return score; }
    int get_goals_for() { return goals_for; }
    int get_goals_against() { return goals_against; }

private:
    std::map<int, std::vector<std::shared_ptr<Player>>> team_players;
    std::string name;
    int score = 0;
    int goals_for = 0;
    int goals_against = 0;
};

class Match
{
public:
    Match(std::pair<std::string, std::string>);
    void set_result(std::pair<std::string, std::string>);
    void add_injureds(std::string info);
    void add_yellow_cards(std::string info);
    void add_red_cards(std::string info);
    void add_goals_and_assists(std::string info);
    void add_match_players(std::vector<std::string>);
    std::vector<std::pair<std::string, float>> get_players_scores() { return players_scores; }
    void make_changes_for_player(std::vector<std::shared_ptr<Player>> players, int side, int post);
    void make_changes(std::vector<std::shared_ptr<Team>> teams, std::vector<std::shared_ptr<Player>> players);
    void print();
    int calculate_goals_concede(int side, int post, int away_goals);

private:
    std::vector<std::pair<std::string, float>> players_scores;
    std::string home_team;
    std::string away_team;
    int home_goals = 0;
    int away_goals = 0;
    std::vector<std::string> injures;
    std::vector<std::string> yellow_cards;
    std::vector<std::string> red_cards;
    std::vector<std::vector<std::string>> match_players;
    std::vector<std::string> goals;
    std::vector<std::string> assists;
    std::vector<std::string> own_goals;
};

typedef std::vector<std::shared_ptr<Match>> Week;

class Account;

const std::map<int, std::vector<std::shared_ptr<Player>>> DEFAULT_FANTASY_TEAM = {
    {GOALKEEPER, {NULL}},
    {DEFENDER, {NULL, NULL}},
    {MIDFIELDER, {NULL}},
    {FORWARD, {NULL}}};

class Fantasy_team
{
    friend class Account;

public:
    Fantasy_team(Account *_user) { user = _user; }
    Fantasy_team() {}
    void reset_transfer_counter();
    bool is_complete(std::map<int, std::vector<std::shared_ptr<Player>>> f_team_players);
    void add_score();
    void delete_player(std::shared_ptr<Player> player);
    void add_player(std::shared_ptr<Player> player);
    void set_captain(std::shared_ptr<Player> player);
    void pass_week_for_ft();
    void print_user_team_style();
    void print_team_of_the_week_style();
    float get_score();
    int get_budget() { return budget; }
    std::map<int, std::vector<std::shared_ptr<Player>>> get_players() { return fantasy_team_players; }
    int calculate_total_cost(std::map<int, std::vector<std::shared_ptr<Player>>> f_team_players);

private:
    float total_scores = 0;
    int buy_transfer_counter = 0;
    int sell_transfer_counter = 0;
    int user_status = NEWCOMER;
    int budget = INITIAL_BUDGET;
    Account *user = NULL;
    std::map<int, std::vector<std::shared_ptr<Player>>> fantasy_team_players = DEFAULT_FANTASY_TEAM;
    std::map<int, std::vector<std::shared_ptr<Player>>> last_week_fantasy_team_players = DEFAULT_FANTASY_TEAM;
    std::shared_ptr<Player> captain = NULL;
    std::shared_ptr<Player> last_captain = NULL;
};

class Account
{
    friend class Fantasy_team;

public:
    Account(std::string _name, std::string _password, int _role);
    int get_role() { return role; }
    void print();
    bool are_you(std::string _name);
    bool is_password_correct(std::string _password);
    std::string get_name() { return name; }
    std::shared_ptr<Fantasy_team> get_f_team() { return user_team; }

private:
    std::string name = JUNK;
    std::string password;
    std::shared_ptr<Fantasy_team> user_team = NULL;
    int role;
};

class My_exeption
{
public:
    My_exeption(std::string s) { message = s; }
    void print_message() { std::cout << message << std::endl; }

private:
    std::string message;
};

template <typename T, typename S>
T find_something(std::vector<T> arr, S s);
std::vector<std::string> seprate_string_by_semicolon(std::string s);
std::pair<std::string, std::string> seprate_string_by_doublecolon(std::string s);
bool compare_two_players_by_name(std::shared_ptr<Player> a, std::shared_ptr<Player> b);
int how_many_repetition(std::vector<std::string> names, std::string name);
int calculate_result(int goals_for, int goals_concede);
float calculate_score(int point);