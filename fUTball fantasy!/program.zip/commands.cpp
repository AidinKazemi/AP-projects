#include "Data_base.hpp"

using namespace std;

void Data_base::make_action(string new_line)
{
    try
    {
        pair<string, string> command_and_arg = seprate_by_question_mark(new_line);
        if (!check_start_of_command(seprate_string_by_delim(command_and_arg.first)[0]))
            throw My_exeption(BAD_REQUEST);
        if (command_and_arg.first == GET_TOTW)
            team_of_the_week(command_and_arg.second);
        else if (command_and_arg.first == GET_PLAYERS)
            players(command_and_arg.second);
        else if (command_and_arg.first == GET_LEAGUE_STANDINGS)
            league_standings(command_and_arg.second);
        else if (command_and_arg.first == GET_USERS_RANKINGS)
            users_ranking(command_and_arg.second);
        else if (command_and_arg.first == GET_MATCHES_RESULT_LEAGUE)
            matches_result_league(command_and_arg.second);
        else if (command_and_arg.first == GET_SQUAD)
            squad(command_and_arg.second);
        else if (command_and_arg.first == GET_SHOW_BUDGET)
            show_budget(command_and_arg.second);
        else if (command_and_arg.first == POST_CLOSE_TRANSFER_WINDOW)
            close_transfer_window(command_and_arg.second);
        else if (command_and_arg.first == POST_OPEN_TRANSFER_WINDOW)
            open_transfer_window(command_and_arg.second);
        else if (command_and_arg.first == POST_PASS_WEEK)
            pass_week(command_and_arg.second);
        else if (command_and_arg.first == POST_SIGNUP)
            signup(command_and_arg.second);
        else if (command_and_arg.first == POST_LOGIN)
            login(command_and_arg.second);
        else if (command_and_arg.first == POST_REGISTER_ADMIN)
            register_admin(command_and_arg.second);
        else if (command_and_arg.first == POST_LOGOUT)
            logout(command_and_arg.second);
        else if (command_and_arg.first == POST_BUY_PLAYER)
            buy_player(command_and_arg.second);
        else if (command_and_arg.first == POST_SELL_PLAYER)
            sell_player(command_and_arg.second);
        else if (command_and_arg.first == POST_SET_CAPTAIN)
            set_captain(command_and_arg.second);
        else
            throw My_exeption(NOT_FOUND);
    }
    catch (My_exeption &e)
    {
        e.print_message();
    }
    catch (out_of_range &e)
    {
        cout << NOT_FOUND << endl;
    }
}

void Data_base::team_of_the_week(const std::string &command_args)
{
    int week_num = current_week - 1;
    vector<string> all_words = seprate_string_by_delim(command_args);
    if (all_words.size() != 0)
    {
        if (all_words.size() == 2)
            week_num = stoi(all_words[1]) - 1;
        else
            throw My_exeption(BAD_REQUEST);
    }
    if (week_num >= current_week || week_num < 0 || (all_words.size() != 0 && all_words[0] != "week_num"))
        throw My_exeption(BAD_REQUEST);
    vector<pair<string, float>> sorted_score_list = get_sorted_score_list(all_weeks[week_num]);
    Fantasy_team team_of_the_week = make_team_of_the_week(sorted_score_list);
    team_of_the_week.print_team_of_the_week_style();
}

vector<pair<string, float>> Data_base::get_sorted_score_list(const Week &_week)
{
    vector<pair<string, float>> scores_to_be_sorted;
    for (auto x : _week)
    {
        vector<pair<string, float>> match_scores = x->get_players_scores();
        scores_to_be_sorted.insert(scores_to_be_sorted.end(), match_scores.begin(), match_scores.end());
    }
    sort(scores_to_be_sorted.begin(), scores_to_be_sorted.end(), compare_name_score);
    return scores_to_be_sorted;
}
Fantasy_team Data_base::make_team_of_the_week(vector<pair<string, float>> sorted_scores)
{
    Fantasy_team team_of_the_week;
    for (auto x : sorted_scores)
    {
        if (team_of_the_week.is_complete(team_of_the_week.get_players()))
            return team_of_the_week;
        shared_ptr<Player> p = find_something(all_players, x.first);
        try
        {
            shared_ptr<Player> s = Player::get_post_specified_player(p->get_position(), p->get_name(), p->get_price());
            s->set_direct_score(x.second);
            team_of_the_week.add_player(s);
        }
        catch (const My_exeption &e)
        {
            continue;
        }
    }
    return NULL;
}
void Data_base::players(const std::string &command_args)
{
    vector<string> all_args = seprate_string_by_delim(command_args);
    if (all_args.size() > 4 || all_args.size() < 2)
        throw My_exeption(BAD_REQUEST);
    replace_dash_with_space(all_args[1]);
    shared_ptr<Team> needed_team = find_something(all_teams, all_args[1]);
    if (all_args[0] != "team_name")
        throw My_exeption(BAD_REQUEST);
    if (needed_team == NULL)
        throw My_exeption(NOT_FOUND);
    vector<shared_ptr<Player>> needed_players;
    if (all_args.size() == 4)
    {
        if (!(all_args[2] == "gk" || all_args[2] == "fw" || all_args[2] == "md" || all_args[2] == "df") ||
            all_args[3] != "ranks")
            throw My_exeption(BAD_REQUEST);
        needed_players = needed_team->get_team_members().at(pos_str_to_int.at(all_args[2]));
        sort(needed_players.begin(), needed_players.end(), compare_player_avg_score);
    }
    else if (all_args.size() == 3)
    {
        bool correct_args = false;
        for (auto x : pos_str_to_int)
            if (all_args[2] == x.first)
            {
                correct_args = true;
                needed_players = needed_team->get_team_members().at(x.second);
            }
        if (all_args[2] == RANKS_ORDER)
        {
            correct_args = true;
            needed_players = turn_map_to_vector(needed_team->get_team_members());
            sort(needed_players.begin(), needed_players.end(), compare_player_avg_score);
        }
        if (!correct_args)
            throw My_exeption(BAD_REQUEST);
    }
    else if (all_args.size() == 2)
    {
        std::map<int, std::vector<std::shared_ptr<Player>>> team_members = needed_team->get_team_members();
        needed_players = turn_map_to_vector(team_members);
    }
    cout << "list of players:" << endl;
    needed_team->print_a_group_of_players(needed_players);
}
void Data_base::league_standings(const string &command_args)
{
    vector<string> all_args = seprate_string_by_delim(command_args);
    if (all_args.size() != 0)
        throw My_exeption(BAD_REQUEST);
    sort(all_teams.begin(), all_teams.end(), compare_teams_for_standing);
    cout << "league standings:" << endl;
    for (int i = 0; i < all_teams.size(); i++)
    {
        cout << i + 1 << ". ";
        all_teams[i]->print();
    }
}
void Data_base::users_ranking(const string &command_args)
{
    vector<string> all_args = seprate_string_by_delim(command_args);
    if (all_args.size() != 0)
        throw My_exeption(BAD_REQUEST);
    if (all_accounts.size() == 0)
        throw My_exeption(EMPTY);
    sort(all_accounts.begin(), all_accounts.end(), compare_users_by_score);
    for (int i = 0; i < all_accounts.size(); i++)
    {
        cout << i + 1 << ". ";
        all_accounts[i]->print();
    }
}
void Data_base::matches_result_league(const string &command_args)
{
    int week_num = current_week - 1;
    vector<string> all_words = seprate_string_by_delim(command_args);
    if (all_words.size() != 0)
    {
        if (all_words.size() == 2)
            week_num = stoi(all_words[1]) - 1;
        else
            throw My_exeption(BAD_REQUEST);
    }
    if (week_num >= current_week || week_num < 0 || (all_words.size() != 0 && all_words[0] != "week_num"))
        throw My_exeption(BAD_REQUEST);
    for (auto x : all_weeks[week_num])
        x->print();
}
void Data_base::squad(const string &command_args)
{
    shared_ptr<Account> needed_user = current_account;
    if (needed_user == NULL || needed_user->get_role() != USER)
        throw My_exeption(PERMISSION_DENIED);
    vector<string> all_words = seprate_string_by_delim(command_args);
    if (all_words.size() != 0)
    {
        if (all_words[0] != "fantasy_team")
            throw My_exeption(BAD_REQUEST);
        bool team_found = false;
        for (auto x : all_accounts)
            if (x->get_name() == all_words[1])
            {
                needed_user = x;
                team_found = true;
                break;
            }
        if (!team_found)
            throw My_exeption(NOT_FOUND);
    }
    needed_user->get_f_team()->print_user_team_style();
}
void Data_base::close_transfer_window(const string &command_args)
{
    vector<string> all_args = seprate_string_by_delim(command_args);
    if (all_args.size() != 0)
        throw My_exeption(BAD_REQUEST);
    if (current_account == NULL || current_account->get_role() != ADMIN)
        throw My_exeption(PERMISSION_DENIED);
    if (transfer_window_status == CLOSE)
        throw My_exeption(BAD_REQUEST);
    transfer_window_status = CLOSE;
    cout << SUCCESSFUL << endl;
}
void Data_base::open_transfer_window(const string &command_args)
{
    vector<string> all_args = seprate_string_by_delim(command_args);
    if (all_args.size() != 0)
        throw My_exeption(BAD_REQUEST);
    if (current_account == NULL || current_account->get_role() != ADMIN)
        throw My_exeption(BAD_REQUEST);
    transfer_window_status = OPEN;
    cout << SUCCESSFUL << endl;
}
void Data_base::pass_week(const string &command_args)
{
    vector<string> all_args = seprate_string_by_delim(command_args);
    if (all_args.size() != 0)
        throw My_exeption(BAD_REQUEST);
    if (current_account == NULL || current_account->get_role() != ADMIN)
        throw My_exeption(PERMISSION_DENIED);
    current_week++;
    for (auto p : all_players)
        p->reset_score();
    for (auto m : all_weeks[current_week - 1])
        m->make_changes(all_teams, all_players);
    for (auto p : all_players)
        p->pass_week_for_player();
    for (auto a : all_accounts)
        a->get_f_team()->pass_week_for_ft();
    cout << SUCCESSFUL << endl;
}
void Data_base::signup(const string &command_args)
{
    if (current_account != NULL)
        throw My_exeption(BAD_REQUEST);
    vector<string> all_args = seprate_string_by_delim(command_args);
    if (all_args.size() != 4 || all_args[0] != "team_name" || all_args[2] != "password")
        throw My_exeption(BAD_REQUEST);
    if (find_something(all_accounts, all_args[1]) != NULL)
        throw My_exeption(BAD_REQUEST);
    shared_ptr<Account> a = make_shared<Account>(all_args[1], all_args[3], USER);
    all_accounts.push_back(a);
    current_account = a;
    cout << SUCCESSFUL << endl;
}
void Data_base::login(const string &command_args)
{
    if (current_account != NULL)
        throw My_exeption(BAD_REQUEST);
    vector<string> all_args = seprate_string_by_delim(command_args);
    if (all_args.size() != 4 || all_args[0] != "team_name" || all_args[2] != "password")
        throw My_exeption(BAD_REQUEST);
    shared_ptr<Account> p = find_something(all_accounts, all_args[1]);
    if (p != NULL)
    {
        if (p->is_password_correct(all_args[3]))
            current_account = p;
        else
            throw My_exeption(PERMISSION_DENIED);
    }
    else
        throw My_exeption(NOT_FOUND);
    cout << SUCCESSFUL << endl;
}
void Data_base::register_admin(const string &command_args)
{
    if (current_account != NULL)
        throw My_exeption(BAD_REQUEST);
    vector<string> all_args = seprate_string_by_delim(command_args);
    if (all_args.size() != 4 || all_args[0] != "username" || all_args[2] != "password")
        throw My_exeption(BAD_REQUEST);
    if (Admin->are_you(all_args[1]) && Admin->is_password_correct(all_args[3]))
    {
        current_account = Admin;
        cout << SUCCESSFUL << endl;
    }
    else
        throw My_exeption(BAD_REQUEST);
}
void Data_base::logout(const string &command_args)
{
    vector<string> all_args = seprate_string_by_delim(command_args);
    if (all_args.size() != 0)
        throw My_exeption(BAD_REQUEST);
    if (current_account == NULL)
        throw My_exeption(BAD_REQUEST);
    current_account = NULL;
    cout << SUCCESSFUL << endl;
}
void Data_base::sell_player(const string &command_args)
{
    if (current_account == NULL || current_account->get_role() != USER)
        throw My_exeption(PERMISSION_DENIED);
    if (transfer_window_status == CLOSE)
        throw My_exeption(PERMISSION_DENIED);
    vector<string> all_args = seprate_string_by_delim(command_args);
    if (all_args[0] != "name")
        throw My_exeption(BAD_REQUEST);
    string player_name = make_string_from_vector(vector<string>(&all_args[1], &all_args[all_args.size()]));
    shared_ptr<Player> p = find_something(all_players, player_name);
    if (p)
    {
        current_account->get_f_team()->delete_player(p);
        cout << SUCCESSFUL << endl;
    }
    else
        throw My_exeption(NOT_FOUND);
}
void Data_base::buy_player(const string &command_args)
{
    if (current_account == NULL || current_account->get_role() != USER)
        throw My_exeption(PERMISSION_DENIED);
    if (transfer_window_status == CLOSE)
        throw My_exeption(PERMISSION_DENIED);
    vector<string> all_args = seprate_string_by_delim(command_args);
    if (all_args[0] != "name")
        throw My_exeption(BAD_REQUEST);
    string player_name = make_string_from_vector(vector<string>(&all_args[1], &all_args[all_args.size()]));
    shared_ptr<Player> p = find_something(all_players, player_name);
    if (p)
    {
        if (!p->are_you_available())
            throw My_exeption("This player is not available for next week");
        if (current_account->get_f_team()->get_budget() < p->get_price())
            throw My_exeption(BAD_REQUEST);
        current_account->get_f_team()->add_player(p);
        cout << SUCCESSFUL << endl;
    }
    else
        throw My_exeption(NOT_FOUND);
}
void Data_base::set_captain(const string &command_args)
{
    if (current_account == NULL || current_account->get_role() != USER)
        throw My_exeption(PERMISSION_DENIED);
    vector<string> all_args = seprate_string_by_delim(command_args);
    if (all_args[0] != "name")
        throw My_exeption(BAD_REQUEST);
    string player_name = make_string_from_vector(vector<string>(&all_args[1], &all_args[all_args.size()]));
    shared_ptr<Player> p = find_something(all_players, player_name);
    if (p)
    {
        current_account->get_f_team()->set_captain(p);
        cout << SUCCESSFUL << endl;
    }
    else
        throw My_exeption(NOT_FOUND);
}
void Data_base::show_budget(const string &command_args)
{
    vector<string> all_args = seprate_string_by_delim(command_args);
    if (all_args.size() != 0)
        throw My_exeption(BAD_REQUEST);
    if (current_account == NULL || current_account->get_role() != USER)
        throw My_exeption(PERMISSION_DENIED);
    cout << current_account->get_f_team()->get_budget() << endl;
}

pair<string, string> seprate_by_question_mark(std::string s)
{
    pair<string, string> sep;
    int q_pos = s.find('?');
    if (q_pos == string::npos)
    {
        sep.first = make_pure_string(s);
        return sep;
    }
    sep.first = make_pure_string(s.substr(0, q_pos - 1));
    if (q_pos == s.size() - 1)
        return sep;
    sep.second = make_pure_string(s.substr(q_pos + 2));
    return sep;
}

void replace_dash_with_space(std::string &s)
{
    for (auto &x : s)
        if (x == '_')
            x = ' ';
}

template <typename T, typename P>
std::vector<T> turn_map_to_vector(std::map<P, std::vector<T>> m)
{
    std::vector<T> final_vector;
    for (auto x : m)
        final_vector.insert(final_vector.end(), x.second.begin(), x.second.end());
    return final_vector;
}

bool compare_name_score(pair<string, float> a, pair<string, float> b)
{
    if (a.second > b.second)
        return true;
    else if (a.second == b.second)
        if (a.first.compare(b.first) < 0)
            return true;
    return false;
}

bool compare_player_name(std::shared_ptr<Player> a, std::shared_ptr<Player> b)
{
    return a->get_name().compare(b->get_name()) < 0;
}

bool compare_player_avg_score(shared_ptr<Player> a, shared_ptr<Player> b)
{
    if (a->get_avg_score() > b->get_avg_score())
        return true;
    else if (a->get_avg_score() == b->get_avg_score())
        if (a->get_name().compare(b->get_name()) < 0)
            return true;
    return false;
}

vector<string> seprate_string_by_delim(string s)
{
    stringstream ss(s);
    vector<string> all_words;
    string new_word;
    while (ss >> new_word)
        all_words.push_back(new_word);
    return all_words;
}

bool compare_teams_for_standing(shared_ptr<Team> a, shared_ptr<Team> b)
{
    if (a->get_score() > b->get_score())
        return true;
    else if (a->get_score() == b->get_score())
        if ((a->get_goals_for() - a->get_goals_against()) > (b->get_goals_for() - b->get_goals_against()))
            return true;
        else if ((a->get_goals_for() - a->get_goals_against()) == (b->get_goals_for() - b->get_goals_against()))
            if (a->get_goals_for() > b->get_goals_for())
                return true;
            else if (a->get_goals_for() == b->get_goals_for())
                if (a->get_name().compare(b->get_name()) < 0)
                    return true;
    return false;
}

bool compare_users_by_score(shared_ptr<Account> a, shared_ptr<Account> b)
{
    if (a->get_f_team()->get_score() > b->get_f_team()->get_score())
        return true;
    else if (a->get_f_team()->get_score() == b->get_f_team()->get_score())
        if (a->get_name().compare(b->get_name()) < 0)
            return true;
    return false;
}

template <typename T, typename S>
T find_something(std::vector<T> arr, S s)
{
    for (auto x : arr)
        if (x->are_you(s))
            return x;
    return NULL;
}

bool check_start_of_command(std::string first_command)
{
    return first_command == "GET" || first_command == "DELETE" || first_command == "PUT" || first_command == "POST";
}

std::string make_string_from_vector(std::vector<string> all_s)
{
    string ret = all_s[0];
    for (int i = 1; i < all_s.size(); i++)
        ret = ret + " " + all_s[i];
    return ret;
}

string make_pure_string(string s)
{
    stringstream st(s);
    string ret, temp;
    st >> ret;
    while (st >> temp)
        ret = ret + " " + temp;
    return ret;
}