#include "const_values.hpp"
#include "classes.hpp"

using namespace std;

float calculate_score(int point)
{
    return 10.0 / (1 + exp((-point) / 6.0));
}

int main()
{
    cout << calculate_score(-3) << endl;
    return 0;
}
// string new_player_info = "ali:1000$";
// int post = 1;
// if (new_player_info.find('\r') != string::npos)
//     new_player_info.erase(new_player_info.find('\r'));
// pair<string, string> name_and_price =
//     seprate_string_by_doublecolon(new_player_info);
// if (name_and_price.second.find('$') != string::npos)
//     name_and_price.second.erase(name_and_price.second.find('$'));
// shared_ptr<Player> new_player = Player::get_post_specified_player(post, name_and_price.first, stoi(name_and_price.second));

// cout << new_player->get_name();
// cout << " " << new_player->get_position();
// cout << " " << new_player->get_price();




// vector<string> _match_information = {"a:b", "4:3", "c", "d", "e", "f:j;x:y;h:OWN_GOAL", "g;gg;ggg", "h;hh;hhh"};
// shared_ptr<Match> new_match = make_shared<Match>(seprate_string_by_doublecolon(_match_information[MATCH]));
// new_match->set_result(seprate_string_by_doublecolon(_match_information[RESULT]));
// new_match->add_injureds(_match_information[INJURED]);
// new_match->add_yellow_cards(_match_information[YELLOW_CARD]);
// new_match->add_red_cards(_match_information[RED_CARD]);
// new_match->add_goals_and_assists(_match_information[GOALS_WITH_ASSISTS]);
// new_match->add_match_players(vector<string>(&_match_information[HOME_TEAM_PLAYERS],
//                                             &_match_information[_match_information.size()]));
// new_match->print();

// cout << "inj" << endl;
// for (auto x : new_match->injures)
//     cout << x << endl;

// cout << "red" << endl;
// for (auto x : new_match->red_cards)
//     cout << x << endl;

// cout << "yellow" << endl;
// for (auto x : new_match->yellow_cards)
//     cout << x << endl;

// cout << "og" << endl;
// for (auto x : new_match->own_goals)
//     cout << x << endl;

// cout << "assists " << new_match->assists.size() << endl;
// for (auto x : new_match->assists)
//     cout << x << endl;

// cout << "goals " << new_match->goals.size() << endl;
// for (auto x : new_match->goals)
//     cout << x << endl;

// for (int i = 0; i < new_match->match_players.size(); i++)
//     for (int j = 0; j < new_match->match_players[i].size(); j++)
//         cout << i << " " << new_match->match_players[i][j] << endl;