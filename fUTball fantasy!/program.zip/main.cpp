#include "Data_base.hpp"

using namespace std;

int main()
{
    Data_base game_data_base;
    string new_line;
    while (getline(cin, new_line))
        game_data_base.make_action(new_line);
    return 0;
}
