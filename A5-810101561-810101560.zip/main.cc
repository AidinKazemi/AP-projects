#include "Game.hh"
#include "environment.hh"
#include "object.hh"
#include <iostream>
#include <SFML/Graphics.hpp>
#include <string>
#include <vector>
#include <fstream>
#include <sstream>
using namespace std;
using namespace sf;

int main()
{
    bool game_is_up = true;
    while (game_is_up)
    {
        cout << PROGRAM_START << std::endl;
        Game_information new_game(JUNK);
        vector<Texture> all_textures = new_game.get_all_textures();
        load_needed_texture(all_textures);
        vector<vector<Building_block>> all_blocks = new_game.get_all_blocks();
        new_game.set_kids_count();
        View view(Vector2f(DEFAULT_VIEW_POS.first, DEFAULT_VIEW_POS.second),
                  Vector2f(HALF_SCREEN_LENGTH * VIEW_SCALE, HALF_SCREEN_HEIGHT * VIEW_SCALE));
        int row_counts = all_blocks.size();
        int column_counts = all_blocks[FIRST_ROW].size();
        int last_move_x = NOTHING, last_move_y = NOTHING;
        int game_status = START_MENU;
        sf::RectangleShape background = make_background(column_counts, row_counts);
        RenderWindow window(VideoMode(HALF_SCREEN_LENGTH * 2, HALF_SCREEN_HEIGHT * 2), "Turtix");
        while (window.isOpen())
        {
            Clock clock;
            Event event;
            if (game_status == START_MENU)
            {
                Sprite menu = make_sprite(all_textures, 0, 0, MENU_TEXTURE);
                Sprite start_game_icon = make_sprite(all_textures, 0, -2, START_TEXTURE);
                Sprite exit_game_icon = make_sprite(all_textures, 0, 2, EXIT_TEXTURE);
                window.clear();
                window.draw(menu);
                window.draw(start_game_icon);
                window.draw(exit_game_icon);
                window.display();
                while (window.pollEvent(event))
                {
                    if (event.type == Event::Closed)
                        game_status = EXIT;
                    if (event.type == Event::MouseButtonPressed)
                    {
                        if (start_game_icon.getGlobalBounds().contains(event.mouseButton.x, event.mouseButton.y))
                            game_status = GAME;
                        else if (exit_game_icon.getGlobalBounds().contains(event.mouseButton.x, event.mouseButton.y))
                            game_status = EXIT;
                    }
                    clock.restart();
                }
            }
            else if (game_status == STOP_MENU)
            {
                View temp_view(Vector2f(HALF_SCREEN_LENGTH, HALF_SCREEN_HEIGHT),
                               Vector2f(HALF_SCREEN_LENGTH * 2, HALF_SCREEN_HEIGHT * 2));
                window.setView(temp_view);
                Sprite menu = make_sprite(all_textures, 0, 0, MENU_TEXTURE);
                Sprite resume_game_icon = make_sprite(all_textures, 0, -2, RESUME_TEXTURE);
                Sprite main_menu_icon = make_sprite(all_textures, 0, 2, MAIN_MENU_TEXTURE);
                window.clear();
                window.draw(menu);
                window.draw(resume_game_icon);
                window.draw(main_menu_icon);
                window.display();
                while (window.pollEvent(event))
                {
                    if (event.type == Event::Closed)
                        game_status = EXIT;
                    if (event.type == Event::MouseButtonPressed)
                    {
                        if (resume_game_icon.getGlobalBounds().contains(event.mouseButton.x, event.mouseButton.y))
                            game_status = GAME;
                        else if (main_menu_icon.getGlobalBounds().contains(event.mouseButton.x, event.mouseButton.y))
                            game_status = MAIN_MENU;
                    }
                    clock.restart();
                }
            }
            else if (game_status == END_OF_GAME)
            {
            }
            else if (game_status == MAIN_MENU)
            {
                window.close();
            }
            else if (game_status == GAME)
            {
                while (window.pollEvent(event))
                {
                    if (event.type == Event::Closed)
                    {
                        game_status = EXIT;
                    }
                    else if (event.type == Event::KeyPressed)
                    {
                        if (event.key.code == sf::Keyboard::Up)
                        {
                            new_game.set_turtix_jump();
                            last_move_y = UP;
                        }
                        if (event.key.code == Keyboard::Right)
                            last_move_x = RIGHT;
                        if (event.key.code == Keyboard::Left)
                            last_move_x = LEFT;
                    }
                    else if (event.type == Event::KeyReleased)
                    {
                        if (event.key.code == sf::Keyboard::Up)
                            last_move_y = NOTHING;
                        if (event.key.code == Keyboard::Left || event.key.code == sf::Keyboard::Right)
                            last_move_x = NOTHING;
                        if (event.key.code == Keyboard::Escape)
                            game_status = STOP_MENU;
                    }
                }
                if (clock.getElapsedTime() >= microseconds(15))
                {
                    window.clear();
                    new_game.move_view(view, row_counts, column_counts);
                    window.setView(view);
                    window.draw(background);
                    for (int j = 0; j < all_blocks.size(); j++)
                        for (int i = 0; i < all_blocks[j].size(); i++)
                            if (all_blocks[j][i].get_texture_name() != SKY_TEXTURE)
                                window.draw(all_blocks[j][i]);
                    new_game.tik(last_move_x, last_move_y, window, view, game_status);
                    clock.restart();
                }
                window.display();
            }
            else if (game_status == EXIT)
            {
                window.close();
                game_is_up = false;
            }
        }
    }
}