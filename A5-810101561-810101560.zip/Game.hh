#ifndef _GAME
#define _GAME

#include "object.hh"
#include "environment.hh"

const std::string PROGRAM_START = "program have been started, please wait...";
const std::string START_TEX_DIR = "sprite/start_tex.png";
const std::string RESUME_TEX_DIR = "sprite/resume_tex.png";
const std::string GAME_OVER_TEX_DIR = "sprite/game_over_tex.png";
const std::string EXIT_TEX_DIR = "sprite/exit_tex.png";
const std::string MAIN_MENU_TEX_DIR = "sprite/main_menu_tex.png";
const int FIRST_ROW = 1;
const int STARS_POINT = 5;
const int DIAMONDS_POINT = 10;
const float VIEW_SCALE = 2.5;
const std::pair<int, int> DEFAULT_VIEW_POS = std::pair<int, int>(1500, 1800);

enum game_states
{
    START_MENU,
    MAIN_MENU,
    STOP_MENU,
    END_OF_GAME,
    GAME,
    EXIT
};

class Game_information
{
public:
    Game_information(int JUNK);
    std::vector<sf::Texture> get_all_textures() { return all_textures; }
    std::vector<std::vector<Building_block>> get_all_blocks() { return all_blocks; }
    void set_turtix(Turtix the_turtix) { turtix = the_turtix; }
    void set_turtix_jump() { turtix.jumping = true; }
    void check_the_explosions();
    void examinate_turtix(int last_move_x, int last_move_y);
    void change_the_textures();
    void draw_total_points(sf::RenderWindow &window, const sf::View &view);
    void make_stars(std::pair<int, int> position);
    void make_diamonds(std::pair<int, int> position);
    void move_view(sf::View &view, int row_count, int column_count);
    std::vector<sf::Texture> get_stars() { return all_textures; }
    void check_objects_collisions(int &last_move_y);
    void draw_life_count(sf::RenderWindow &window, const sf::View &view);
    void set_kids_count() { kids_count = kids.size(); }
    void make_others_move();
    void draw_everything(sf::RenderWindow &window, const sf::View &view);
    void tik(int last_move_x, int last_move_y, sf::RenderWindow &window, const sf::View &view, int &game_status);

protected:
    void set_font() { arial.loadFromFile("arial.ttf"); }
    void read_map_file();
    std::vector<sf::Texture> all_textures;
    std::vector<std::vector<Building_block>> all_blocks;
    Turtix turtix;
    Portal portal;
    std::vector<Star> all_stars;
    std::vector<Diamond> all_diamonds;
    int point = 0;
    sf::Font arial;
    std::vector<Enemy_1> all_enemy1;
    std::vector<Enemy_2> all_enemy2;
    std::vector<Kid> kids;
    int kids_count = JUNK;
};

sf::RectangleShape make_background(int column_counts, int row_counts);
void load_needed_texture(std::vector<sf::Texture> &all_textures);
sf::Sprite make_sprite(std::vector<sf::Texture> &all_textures, int x_offset, int y_offset, int texture_name);

#endif