#include "environment.hh"
#include <iostream>
#include <SFML/Graphics.hpp>
#include <string>
#include <vector>
#include <fstream>

Building_block::Building_block(int init_x, int init_y, int texture_name,
                               int init_height, int init_width, std::vector<sf::Texture> all_textures)
    : Environmental_element(init_x, init_y, init_height, init_width)

{
    block_texture = all_textures[texture_name];
    block_texture_name = texture_name;
    this->set_vertex_position();
    this->set_vertex_coords();
};
void Building_block::draw(sf::RenderTarget &window, sf::RenderStates states) const
{
    window.draw(block_vertices, &block_texture);
};
void Building_block::set_vertex_position()
{
    sf::VertexArray vertices(sf::Quads, 4);
    for (int i = 0; i < CORNERS_COUNT; i++)
        vertices[i].position = sf::Vector2f(corners[i].first, corners[i].second);

    block_vertices = vertices;
}
void Building_block::set_vertex_coords()
{
    std::vector<std::pair<int, int>> tex_corners = find_corners(width, height, 0, 0);
    for (int i = 0; i < CORNERS_COUNT; i++)
        block_vertices[i].texCoords = sf::Vector2f(tex_corners[i].first, tex_corners[i].second);
}
// bool Building_block::check_being_in_window(int i, int j)
// {
//     for (int x = 0; x < CORNERS_COUNT; x++)
//         if ((i - HALF_SCREEN_LENGTH <= corners[x].first && corners[x].first <= i + HALF_SCREEN_LENGTH) &&
//             (j - HALF_SCREEN_HEIGHT <= corners[x].second && corners[x].second <= j + HALF_SCREEN_HEIGHT))
//             return true;
//     return false;
// }

std::vector<std::pair<int, int>> find_corners(int x_offset, int y_ofsset, int base_x, int base_y)
{
    std::vector<std::pair<int, int>> corners;
    corners.push_back(std::pair<int, int>(base_x, base_y));
    corners.push_back(std::pair<int, int>(base_x + x_offset, base_y));
    corners.push_back(std::pair<int, int>(base_x + x_offset, base_y + y_ofsset));
    corners.push_back(std::pair<int, int>(base_x, base_y + y_ofsset));
    return corners;
}

void make_and_push_block(int x, int y, std::vector<Building_block> &all_blocks,
                         std::vector<sf::Texture> all_textures, int texture_name)
{
    Building_block new_block(x * BLOCK_SIZE,
                             y * BLOCK_SIZE, texture_name,
                             BLOCK_SIZE, BLOCK_SIZE,
                             all_textures);
    all_blocks.push_back(new_block);
}

void load_new_texture(std::string texture_name, std::vector<sf::Texture> &all_textures)
{
    sf::Texture new_texture;
    if (!new_texture.loadFromFile(texture_name))
    {
        std::cout << "problem_texture_load";
        abort();
    }
    all_textures.push_back(new_texture);
}
