#ifndef _OBJECT
#define _OBJECT

#include <SFML/Graphics.hpp>
#include <iostream>
#include <vector>
#include "environment.hh"

const int TURTIX_WIDTH = 120;
const int TURTIX_HEIGHT = 120;
const int FRAMES_TO_PASS_FOR_SHOWING = 4;
const int FRAMES_TO_PASS_FOR_CHANGE_STATUS = 100;

enum MOVES
{
    UP,
    DOWN,
    RIGHT,
    LEFT,
    SPACE,
    NOTHING
};
enum CORNERS
{
    UP_LEFT,
    UP_RIGHT,
    DOWN_RIGHT,
    DOWN_LEFT,
    MOVING_VALID
};

enum GLOBAL_LIVINGS_STATUS
{
    NORMAL,
    HIT,
    DEATH
};
enum ENEMY2_STATUS
{
    SAFE,
    DANGEROUS
};
enum KID_STATUS
{
    TRAPPED,
    FREE
};
enum PORTAL_STATUS
{
    CLOSE,
    OPEN
};

const int STEP_LENGTH = 5;
const int STARS_ROW_AND_COL_COUNT = 3;
const int TIME_STEP = 1;
const int THE_VX = 15;
const int GRAVITY = 5;
const int THE_VY = -75;
const int STAR_SIZE = 70;
const int DIAMOND_SIZE = 70;
const int GUTTER_SIZE = 10;
const int ENEMEIS_NORMALIZER = 3;

const std::vector<sf::Texture> vt3(3);
const std::vector<sf::Texture> vt4(4);
const std::vector<sf::Texture> vt6(6);
const std::vector<sf::Texture> vt8(8);
const std::vector<sf::Texture> vt10(10);
const std::vector<sf::Texture> vt16(16);
const std::vector<sf::Texture> vt30(30);
const std::vector<sf::Texture> vt2(2);
const std::vector<sf::Texture> vt1(1);

std::pair<int, int> find_equal_Building_block(std::pair<int, int> point);
std::pair<int, int> find_equal_position(int i, int line_number);
int is_moving_valid(int new_x, int new_y, std::vector<std::vector<Building_block>> &all_blocks);

class Object : public sf::Sprite
{
public:
    Object(){};
    Object(int x, int y, int vx, int vy);
    void set_Vy(int vy) { Vy = vy; };
    void set_Vx(int vx) { Vx = vx; };
    void turn_over() { Vx = -Vx; };
    int get_Vx() { return Vx; }
    int get_Vy() { return Vy; }
    void expulsion() { existance = false; };
    bool still_exists() { return existance; }
    virtual void make_the_next_move(){};
    void calculate_Vy_from_gravity();

protected:
    int Vx;
    int Vy;
    bool existance = true;
};

class Turtix : public Object
{
public:
    Turtix() {}
    Turtix(int x, int y, int vx, int vy, std::vector<std::vector<Building_block>> *all_the_blocks)
        : Object(x, y, vx, vy)
    {
        set_motion_frames();
        all_blocks = all_the_blocks;
    }
    int get_life_count() { return lives; }
    void set_motion_frames();
    void reset_counters();
    void make_the_next_move();
    void move_turtix_x();
    void move_turtix_y();
    void hit()
    {
        lives--;
        status = HIT;
    }
    void stand()
    {
        if (last_x_direction == RIGHT)
            this->setTexture(standingr);
        else
            this->setTexture(standingl);
    };
    int get_status() { return status; }
    bool jumping = true;

protected:
    void handle_getting_hit();
    int status = NORMAL;
    int runr_count = 0;
    int runl_count = 0;
    int last_x_direction = RIGHT;
    int lives = 3;
    int frame_counts = 0;
    std::vector<std::vector<Building_block>> *all_blocks;
    sf::Texture standingr;
    sf::Texture standingl;
    std::vector<sf::Texture> runningr_frames = vt8;
    std::vector<sf::Texture> runningl_frames = vt8;
};

class Kid : public Object
{
public:
    Kid(int x, int y, int vx, int vy, std::vector<std::vector<Building_block>> *all_the_blocks);

    void release();
    void trapped_motions();
    void free_motions();
    void make_act();
    int get_status() { return status; }
    void reset_counters()
    {
        fc = 0;
        tc = 0;
    };
    void respawn_kid();
    void set_motion_frames();
    void make_the_next_move();

private:
    std::pair<int, int> first_location;
    int frame_counter = 0;
    KID_STATUS status = TRAPPED;
    int tc = 0;
    int fc = 0;
    std::vector<sf::Texture> trapped_frames = vt10;
    std::vector<sf::Texture> freer_frames = vt8;
    std::vector<sf::Texture> freel_frames = vt8;
    std::vector<std::vector<Building_block>> *all_blocks;
};

class Star : public Object
{
public:
    Star(int x, int y, int vx, int vy, std::vector<std::vector<Building_block>> *all_the_blocks);
    void change_texture()
    {
        counter = (counter + 1) % 16;
        this->setTexture(star_frames[counter]);
    };
    bool is_colision_happend(Turtix turtix);

private:
    void set_motion_frames();
    int counter = 0;
    std::vector<sf::Texture> star_frames = vt16;
    std::vector<std::vector<Building_block>> *all_blocks;
};

class Diamond : public Object
{
public:
    Diamond(int x, int y, int vx, int vy, std::vector<std::vector<Building_block>> *all_the_blocks);
    void change_texture()
    {
        counter = (counter + 1) % 16;
        this->setTexture(diamond_frames[counter]);
    };
    bool is_colision_happend(Turtix turtix);

private:
    void set_motion_frames();
    int counter = 0;
    std::vector<sf::Texture> diamond_frames = vt16;
    std::vector<std::vector<Building_block>> *all_blocks;
};

class Enemy_1 : public Object
{
public:
    Enemy_1(int x, int y, int vx, int vy, std::vector<std::vector<Building_block>> *all_the_blocks);
    void hit()
    {
        if (status != HIT)
        {
            status = HIT;
            lives--;
        }
    };
    void make_the_next_move();
    int get_status() { return status; }

private:
    int frame_counter = 0;
    std::vector<std::vector<Building_block>> *all_blocks;
    int lives = 2;
    int l2rc = 0;
    int l2lc = 0;
    int l1rc = 0;
    int l1lc = 0;
    int h2c = 0;
    int h1c = 0;
    int dc = 0;
    int status = NORMAL;
    std::vector<sf::Texture> l2r_frames = vt4;
    std::vector<sf::Texture> l2l_frames = vt4;
    std::vector<sf::Texture> l1r_frames = vt4;
    std::vector<sf::Texture> l1l_frames = vt4;
    std::vector<sf::Texture> h2r_frames = vt3;
    std::vector<sf::Texture> h2l_frames = vt3;
    std::vector<sf::Texture> h1r_frames = vt3;
    std::vector<sf::Texture> h1l_frames = vt3;
    std::vector<sf::Texture> dr_frames = vt4;
    std::vector<sf::Texture> dl_frames = vt4;
    void hit_motions();
    void normal_motions();
    void death_motions();
    void make_act();
    void reset_counters();
    void set_motion_frames();
    bool recognize_edge();
};

class Enemy_2 : public Object
{
public:
    Enemy_2(int x, int y, int vx, int vy, std::vector<std::vector<Building_block>> *all_the_blocks);
    void hit()
    {
        status = DEATH;
    };
    bool is_this_dangerous()
    {
        if (status == DANGEROUS)
            return true;
        return false;
    };
    void make_act()
    {
        if (status == DEATH)
            this->death_motions();
        else
            this->normal_motions();
    };
    void set_motion_frames();
    int get_status() { return status; }
    void make_the_next_move();
    bool recognize_edge();

private:
    int frame_counter = 0;
    int nc = 0;
    int dc = 0;
    int status = ENEMY2_STATUS::SAFE;
    std::vector<sf::Texture> dr_frames = vt6;
    std::vector<sf::Texture> dl_frames = vt6;
    std::vector<sf::Texture> nr_frames = vt30;
    std::vector<sf::Texture> nl_frames = vt30;
    std::vector<std::vector<Building_block>> *all_blocks;
    void normal_motions();
    void death_motions();
};

class Portal : public Object
{
public:
    Portal() {}
    Portal(int x, int y, int vx, int vy, std::vector<std::vector<Building_block>> *all_the_blocks);
    void open() { status = OPEN; };
    bool is_this_open()
    {
        if (status == OPEN)
            return true;
        return false;
    };
    int get_status() { return status; }
    void set_the_texture()
    {
        if (status == OPEN)
            setTexture(portal_tex[1]);
        else
            setTexture(portal_tex[0]);
    }

private:
    PORTAL_STATUS status = CLOSE;
    void set_motion_frames();
    std::vector<sf::Texture> portal_tex = vt2;
    std::vector<std::vector<Building_block>> *all_blocks;
};
#endif