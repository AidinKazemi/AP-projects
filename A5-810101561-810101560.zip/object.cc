#include "object.hh"

std::pair<int, int> find_equal_Building_block(std::pair<int, int> point)
{
    std::pair<int, int> equal_block;
    equal_block.first = (point.first) / BLOCK_SIZE;
    equal_block.second = (point.second) / BLOCK_SIZE;
    return equal_block;
}
std::pair<int, int> find_equal_position(int i, int line_number)
{
    std::pair<int, int> equal_position;
    equal_position.first = (i / BLOCK_DOTS_COUNT) * BLOCK_SIZE;
    equal_position.second = line_number * BLOCK_SIZE;
    return equal_position;
}
int is_moving_valid(int new_x, int new_y, std::vector<std::vector<Building_block>> &all_blocks)
{
    std::vector<std::pair<int, int>> trutix_corners = find_corners(TURTIX_WIDTH, TURTIX_HEIGHT, new_x, new_y);
    for (int i = 0; i < CORNERS_COUNT; i++)
    {
        std::pair<int, int> equal_block_index = find_equal_Building_block(trutix_corners[i]);
        if (all_blocks[equal_block_index.second][equal_block_index.first].get_texture_name() == GROUND_TEXTURE ||
            all_blocks[equal_block_index.second][equal_block_index.first].get_texture_name() == GRASS_TEXTURE)
            return i;
    }
    return MOVING_VALID;
}

void Object::calculate_Vy_from_gravity()
{
    if (Vy < -THE_VY)
        Vy += TIME_STEP * GRAVITY;
}
Object::Object(int x, int y, int vx = 0, int vy = 0)
{
    Vx = vx;
    Vy = vy;
    this->setPosition(x, y);
}

void Turtix::handle_getting_hit()
{
    if (frame_counts % FRAMES_TO_PASS_FOR_SHOWING == 0)
    {
        existance = !existance;
        if (frame_counts >= FRAMES_TO_PASS_FOR_CHANGE_STATUS)
        {
            status = NORMAL;
            frame_counts = 0;
            existance = true;
        }
    }
    frame_counts++;
}
void Turtix::move_turtix_x()
{
    this->move(TIME_STEP * Vx, 0);
    if (Vx > 0)
    {
        runr_count = (runr_count + 1) % 8;
        last_x_direction = RIGHT;
        this->setTexture(runningr_frames[runr_count]);
    }
    else if (Vx < 0)
    {
        last_x_direction = LEFT;
        runl_count = (runl_count + 1) % 8;
        this->setTexture(runningl_frames[runl_count]);
    }
};
void Turtix::move_turtix_y()
{
    jumping = true;
    this->move(0, TIME_STEP * Vy);
};
void Turtix::reset_counters()
{
    runr_count = 0;
    runl_count = 0;
}
void Turtix::set_motion_frames()
{
    standingr.loadFromFile("sprite/standingrr.png");
    standingl.loadFromFile("sprite/standingll.png");
    runningl_frames[0].loadFromFile("sprite/running1l.png");
    runningl_frames[1].loadFromFile("sprite/running2l.png");
    runningl_frames[2].loadFromFile("sprite/running3l.png");
    runningl_frames[3].loadFromFile("sprite/running4l.png");
    runningl_frames[4].loadFromFile("sprite/running5l.png");
    runningl_frames[5].loadFromFile("sprite/running6l.png");
    runningl_frames[6].loadFromFile("sprite/running7l.png");
    runningl_frames[7].loadFromFile("sprite/running8l.png");
    runningr_frames[0].loadFromFile("sprite/running1r.png");
    runningr_frames[1].loadFromFile("sprite/running2r.png");
    runningr_frames[2].loadFromFile("sprite/running3r.png");
    runningr_frames[3].loadFromFile("sprite/running4r.png");
    runningr_frames[4].loadFromFile("sprite/running5r.png");
    runningr_frames[5].loadFromFile("sprite/running6r.png");
    runningr_frames[6].loadFromFile("sprite/running7r.png");
    runningr_frames[7].loadFromFile("sprite/running8r.png");
}
void Turtix::make_the_next_move()
{
    if (status == HIT)
        handle_getting_hit();
    this->calculate_Vy_from_gravity();
    int x_pos = this->getPosition().x,
        new_x = x_pos + Vx * TIME_STEP;
    int y_pos = this->getPosition().y,
        new_y = y_pos + Vy * TIME_STEP;
    if (is_moving_valid(new_x, y_pos, *all_blocks) == MOVING_VALID)
    {
        this->move_turtix_x();
    }
    if (is_moving_valid(x_pos, new_y, *all_blocks) == MOVING_VALID)
        this->move_turtix_y();
    else
    {
        if (is_moving_valid(x_pos, new_y, *all_blocks) == DOWN_LEFT || is_moving_valid(x_pos, new_y, *all_blocks) == DOWN_RIGHT)
            jumping = false;
        Vy = 0;
    }
}

void Kid::release()
{
    status = FREE;
    Vx = THE_VX;
}
void Kid::trapped_motions()
{
    tc = (tc + 1) % 10;
    this->setTexture(trapped_frames[tc]);
};
void Kid::free_motions()
{
    if (Vx > 0)
    {
        fc = (fc + 1) % 8;
        this->setTexture(freer_frames[fc]);
    }
    else
    {
        fc = (fc + 1) % 8;
        this->setTexture(freel_frames[fc]);
    }
    this->move(TIME_STEP * Vx, 0);
};
void Kid::make_act()
{
    switch (status)
    {
    case TRAPPED:
        this->trapped_motions();
        break;
    case FREE:
        this->free_motions();
        break;
    default:
        break;
    }
};

void Kid::set_motion_frames()
{
    trapped_frames[0].loadFromFile("sprite/egg1.png");
    trapped_frames[1].loadFromFile("sprite/egg2.png");
    trapped_frames[2].loadFromFile("sprite/egg3.png");
    trapped_frames[3].loadFromFile("sprite/egg4.png");
    trapped_frames[4].loadFromFile("sprite/egg5.png");
    trapped_frames[5].loadFromFile("sprite/egg6.png");
    trapped_frames[6].loadFromFile("sprite/egg7.png");
    trapped_frames[7].loadFromFile("sprite/egg8.png");
    trapped_frames[8].loadFromFile("sprite/egg9.png");
    trapped_frames[9].loadFromFile("sprite/egg10.png");
    freer_frames[0].loadFromFile("sprite/babyrunningr1.png");
    freer_frames[1].loadFromFile("sprite/babyrunningr2.png");
    freer_frames[2].loadFromFile("sprite/babyrunningr3.png");
    freer_frames[3].loadFromFile("sprite/babyrunningr4.png");
    freer_frames[4].loadFromFile("sprite/babyrunningr5.png");
    freer_frames[5].loadFromFile("sprite/babyrunningr6.png");
    freer_frames[6].loadFromFile("sprite/babyrunningr7.png");
    freer_frames[7].loadFromFile("sprite/babyrunningr8.png");
    freel_frames[0].loadFromFile("sprite/babyrunningl1.png");
    freel_frames[1].loadFromFile("sprite/babyrunningl2.png");
    freel_frames[2].loadFromFile("sprite/babyrunningl3.png");
    freel_frames[3].loadFromFile("sprite/babyrunningl4.png");
    freel_frames[4].loadFromFile("sprite/babyrunningl5.png");
    freel_frames[5].loadFromFile("sprite/babyrunningl6.png");
    freel_frames[6].loadFromFile("sprite/babyrunningl7.png");
    freel_frames[7].loadFromFile("sprite/babyrunningl8.png");
}
Kid::Kid(int x, int y, int vx, int vy, std::vector<std::vector<Building_block>> *all_the_blocks)
    : Object(x, y, vx, vy)
{
    first_location.first = x;
    first_location.second = y;
    set_motion_frames();
    all_blocks = all_the_blocks;
    status = TRAPPED;
}
void Kid::make_the_next_move()
{
    calculate_Vy_from_gravity();
    int x_pos = this->getPosition().x,
        new_x = x_pos + Vx * TIME_STEP;
    int y_pos = this->getPosition().y,
        new_y = y_pos + Vy * TIME_STEP;
    if (is_moving_valid(new_x, y_pos, *all_blocks) == MOVING_VALID)
    {
        make_act();
    }
    else
    {
        reset_counters();
        Vx = -Vx;
        make_act();
    }
    if (is_moving_valid(x_pos, new_y, *all_blocks) == MOVING_VALID)
        this->move(0, Vy * TIME_STEP);
    else
        Vy = 0;
}

void Star::set_motion_frames()
{
    star_frames[0].loadFromFile("sprite/gstar1.png");
    star_frames[1].loadFromFile("sprite/gstar2.png");
    star_frames[2].loadFromFile("sprite/gstar3.png");
    star_frames[3].loadFromFile("sprite/gstar4.png");
    star_frames[4].loadFromFile("sprite/gstar5.png");
    star_frames[5].loadFromFile("sprite/gstar6.png");
    star_frames[6].loadFromFile("sprite/gstar7.png");
    star_frames[7].loadFromFile("sprite/gstar8.png");
    star_frames[8].loadFromFile("sprite/gstar9.png");
    star_frames[9].loadFromFile("sprite/gstar10.png");
    star_frames[10].loadFromFile("sprite/gstar11.png");
    star_frames[11].loadFromFile("sprite/gstar12.png");
    star_frames[12].loadFromFile("sprite/gstar13.png");
    star_frames[13].loadFromFile("sprite/gstar14.png");
    star_frames[14].loadFromFile("sprite/gstar15.png");
    star_frames[15].loadFromFile("sprite/gstar16.png");
}
Star::Star(int x, int y, int vx, int vy, std::vector<std::vector<Building_block>> *all_the_blocks)
    : Object(x, y, vx, vy)
{
    this->set_motion_frames();
    all_blocks = all_the_blocks;
}
bool Star::is_colision_happend(Turtix turtix)
{
    if (existance == true && this->getGlobalBounds().intersects(turtix.getGlobalBounds()))
        return true;
    return false;
}

Diamond::Diamond(int x, int y, int vx, int vy, std::vector<std::vector<Building_block>> *all_the_blocks)
    : Object(x, y, vx, vy)
{
    this->set_motion_frames();
    all_blocks = all_the_blocks;
}
bool Diamond::is_colision_happend(Turtix turtix)
{
    if (existance == true && this->getGlobalBounds().intersects(turtix.getGlobalBounds()))
        return true;
    return false;
}
void Diamond::set_motion_frames()
{
    diamond_frames[0].loadFromFile("sprite/bdiamond1.png");
    diamond_frames[1].loadFromFile("sprite/bdiamond2.png");
    diamond_frames[2].loadFromFile("sprite/bdiamond3.png");
    diamond_frames[3].loadFromFile("sprite/bdiamond4.png");
    diamond_frames[4].loadFromFile("sprite/bdiamond5.png");
    diamond_frames[5].loadFromFile("sprite/bdiamond6.png");
    diamond_frames[6].loadFromFile("sprite/bdiamond7.png");
    diamond_frames[7].loadFromFile("sprite/bdiamond8.png");
    diamond_frames[8].loadFromFile("sprite/bdiamond9.png");
    diamond_frames[9].loadFromFile("sprite/bdiamond10.png");
    diamond_frames[10].loadFromFile("sprite/bdiamond11.png");
    diamond_frames[11].loadFromFile("sprite/bdiamond12.png");
    diamond_frames[12].loadFromFile("sprite/bdiamond13.png");
    diamond_frames[13].loadFromFile("sprite/bdiamond14.png");
    diamond_frames[14].loadFromFile("sprite/bdiamond15.png");
    diamond_frames[15].loadFromFile("sprite/bdiamond16.png");
}

void Enemy_1::hit_motions()
{
    if (lives == 1)
    {
        if (Vx > 0)
            this->setTexture(h2r_frames[h2c]);
        else
            this->setTexture(h2l_frames[h2c]);
        h2c++;
        if (h2c > 2)
        {
            status = NORMAL;
        }
    }
    else
    {
        if (Vx > 0)
            this->setTexture(h1r_frames[h1c]);
        else
            this->setTexture(h1l_frames[h1c]);
        h1c++;
        if (h1c > 2)
            status = DEATH;
    }
};
void Enemy_1::normal_motions()
{
    this->move(TIME_STEP * Vx, 0);
    if (lives == 2)
    {
        if (Vx > 0)
        {
            l2rc = (l2rc + 1) % 4;
            this->setTexture(l2r_frames[l2rc]);
        }
        else if (Vx < 0)
        {
            l2lc = (l2lc + 1) % 4;
            this->setTexture(l2l_frames[l2lc]);
        };
    }
    else if (Vx > 0)
    {
        l1rc = (l1rc + 1) % 4;
        this->setTexture(l1r_frames[l1rc]);
    }
    else if (Vx < 0)
    {
        l1lc = (l1lc + 1) % 4;
        this->setTexture(l1l_frames[l1lc]);
    };
};
void Enemy_1::death_motions()
{
    if (Vx > 0)
        this->setTexture(dr_frames[dc]);
    else
        this->setTexture(dl_frames[dc]);
    dc++;
    if (dc > 3)
        this->expulsion();
};
void Enemy_1::make_act()
{
    switch (status)
    {
    case NORMAL:
        this->normal_motions();
        break;
    case HIT:
        this->hit_motions();
        break;
    case DEATH:
        this->death_motions();
        break;
    default:
        break;
    }
};
void Enemy_1::reset_counters()
{
    l2rc = 0;
    l2lc = 0;
    l1rc = 0;
    l1lc = 0;
}

Enemy_1::Enemy_1(int x, int y, int vx, int vy, std::vector<std::vector<Building_block>> *all_the_blocks)
    : Object(x, y, vx, vy)
{
    set_motion_frames();
    all_blocks = all_the_blocks;
}
void Enemy_1::set_motion_frames()
{
    l2r_frames[0].loadFromFile("sprite/enemy1lives2r1.png");
    l2r_frames[1].loadFromFile("sprite/enemy1lives2r2.png");
    l2r_frames[2].loadFromFile("sprite/enemy1lives2r3.png");
    l2r_frames[3].loadFromFile("sprite/enemy1lives2r4.png");
    l2l_frames[0].loadFromFile("sprite/enemy1lives2l1.png");
    l2l_frames[1].loadFromFile("sprite/enemy1lives2l2.png");
    l2l_frames[2].loadFromFile("sprite/enemy1lives2l3.png");
    l2l_frames[3].loadFromFile("sprite/enemy1lives2l4.png");
    l1r_frames[0].loadFromFile("sprite/enemy1lives1r1.png");
    l1r_frames[1].loadFromFile("sprite/enemy1lives1r2.png");
    l1r_frames[2].loadFromFile("sprite/enemy1lives1r3.png");
    l1r_frames[3].loadFromFile("sprite/enemy1lives1r4.png");
    l1l_frames[0].loadFromFile("sprite/enemy1lives1l1.png");
    l1l_frames[1].loadFromFile("sprite/enemy1lives1l2.png");
    l1l_frames[2].loadFromFile("sprite/enemy1lives1l3.png");
    l1l_frames[3].loadFromFile("sprite/enemy1lives1l4.png");
    h2r_frames[0].loadFromFile("sprite/enemy1hit2r1.png");
    h2r_frames[1].loadFromFile("sprite/enemy1hit2r2.png");
    h2r_frames[2].loadFromFile("sprite/enemy1hit2r3.png");
    h2l_frames[0].loadFromFile("sprite/enemy1hit2l1.png");
    h2l_frames[1].loadFromFile("sprite/enemy1hit2l2.png");
    h2l_frames[2].loadFromFile("sprite/enemy1hit2l3.png");
    h1r_frames[0].loadFromFile("sprite/enemy1hit1r1.png");
    h1r_frames[1].loadFromFile("sprite/enemy1hit1r2.png");
    h1r_frames[2].loadFromFile("sprite/enemy1hit1r3.png");
    h1l_frames[0].loadFromFile("sprite/enemy1hit1l1.png");
    h1l_frames[1].loadFromFile("sprite/enemy1hit1l2.png");
    h1l_frames[2].loadFromFile("sprite/enemy1hit1l3.png");
    dr_frames[0].loadFromFile("sprite/enemy1deathr1.png");
    dr_frames[1].loadFromFile("sprite/enemy1deathr2.png");
    dr_frames[2].loadFromFile("sprite/enemy1deathr3.png");
    dr_frames[3].loadFromFile("sprite/enemy1deathr4.png");
    dl_frames[0].loadFromFile("sprite/enemy1deathl1.png");
    dl_frames[1].loadFromFile("sprite/enemy1deathl2.png");
    dl_frames[2].loadFromFile("sprite/enemy1deathl3.png");
    dl_frames[3].loadFromFile("sprite/enemy1deathl4.png");
}
bool Enemy_1::recognize_edge()
{
    Enemy_1 fake_enemy = *this;
    fake_enemy.move(Vx * 5 * TIME_STEP, 0);
    fake_enemy.calculate_Vy_from_gravity();
    int x_pos = fake_enemy.getPosition().x;
    int y_pos = fake_enemy.getPosition().y,
        new_y = y_pos + Vy * TIME_STEP;
    if (is_moving_valid(x_pos, new_y, *all_blocks) == MOVING_VALID)
        return true;
    return false;
}
void Enemy_1::make_the_next_move()
{
    if (frame_counter % ENEMEIS_NORMALIZER == 0)
    {
        calculate_Vy_from_gravity();
        int x_pos = this->getPosition().x,
            new_x = x_pos + Vx * TIME_STEP;
        int y_pos = this->getPosition().y,
            new_y = y_pos + Vy * TIME_STEP;
        if (is_moving_valid(new_x, y_pos, *all_blocks) == MOVING_VALID && !recognize_edge())
        {
            make_act();
        }
        else
        {
            reset_counters();
            Vx = -Vx;
            make_act();
        }
        if (is_moving_valid(x_pos, new_y, *all_blocks) == MOVING_VALID)
            this->move(0, Vy * TIME_STEP);
        else
        {
            Vy = 0;
        }
        frame_counter = 0;
    }
    frame_counter++;
}

void Enemy_2::normal_motions()
{
    this->move(TIME_STEP * Vx, 0);
    nc = (nc + 1) % 30;
    if (nc >= 10 && nc <= 27)
        status = DANGEROUS;
    else
        status = SAFE;
    if (Vx > 0)
        this->setTexture(nr_frames[nc]);
    else
        this->setTexture(nl_frames[nc]);
};
void Enemy_2::death_motions()
{
    if (Vx > 0)
        this->setTexture(dr_frames[dc]);
    else
        this->setTexture(dl_frames[dc]);
    dc++;
    if (dc > 5)
        this->expulsion();
};

void Enemy_2::set_motion_frames()
{
    dr_frames[0].loadFromFile("sprite/deathy1r.png");
    dr_frames[1].loadFromFile("sprite/deathy2r.png");
    dr_frames[2].loadFromFile("sprite/deathy3r.png");
    dr_frames[3].loadFromFile("sprite/deathy4r.png");
    dr_frames[4].loadFromFile("sprite/deathy5r.png");
    dr_frames[5].loadFromFile("sprite/deathy6r.png");
    dl_frames[0].loadFromFile("sprite/deathy1l.png");
    dl_frames[1].loadFromFile("sprite/deathy2l.png");
    dl_frames[2].loadFromFile("sprite/deathy3l.png");
    dl_frames[3].loadFromFile("sprite/deathy4l.png");
    dl_frames[4].loadFromFile("sprite/deathy5l.png");
    dl_frames[5].loadFromFile("sprite/deathy6l.png");
    nr_frames[0].loadFromFile("sprite/standy1r.png");
    nr_frames[1].loadFromFile("sprite/standy2r.png");
    nr_frames[2].loadFromFile("sprite/standy3r.png");
    nr_frames[3].loadFromFile("sprite/standy4r.png");
    nr_frames[4].loadFromFile("sprite/standy5r.png");
    nr_frames[5].loadFromFile("sprite/standy6r.png");
    nr_frames[6].loadFromFile("sprite/standy7r.png");
    nr_frames[7].loadFromFile("sprite/standy8r.png");
    nr_frames[8].loadFromFile("sprite/standy9r.png");
    nr_frames[9].loadFromFile("sprite/standy10r.png");
    nr_frames[10].loadFromFile("sprite/standy11r.png");
    nr_frames[11].loadFromFile("sprite/standy12r.png");
    nr_frames[12].loadFromFile("sprite/movey1r.png");
    nr_frames[13].loadFromFile("sprite/movey2r.png");
    nr_frames[14].loadFromFile("sprite/movey3r.png");
    nr_frames[15].loadFromFile("sprite/movey4r.png");
    nr_frames[16].loadFromFile("sprite/movey5r.png");
    nr_frames[17].loadFromFile("sprite/movey6r.png");
    nr_frames[18].loadFromFile("sprite/movey7r.png");
    nr_frames[19].loadFromFile("sprite/movey8r.png");
    nr_frames[20].loadFromFile("sprite/movey9r.png");
    nr_frames[21].loadFromFile("sprite/movey10r.png");
    nr_frames[22].loadFromFile("sprite/movey11r.png");
    nr_frames[23].loadFromFile("sprite/movey12r.png");
    nr_frames[24].loadFromFile("sprite/movey13r.png");
    nr_frames[25].loadFromFile("sprite/movey14r.png");
    nr_frames[26].loadFromFile("sprite/movey15r.png");
    nr_frames[27].loadFromFile("sprite/movey16r.png");
    nr_frames[28].loadFromFile("sprite/movey17r.png");
    nr_frames[29].loadFromFile("sprite/movey18r.png");
    nl_frames[0].loadFromFile("sprite/standy1l.png");
    nl_frames[1].loadFromFile("sprite/standy2l.png");
    nl_frames[2].loadFromFile("sprite/standy3l.png");
    nl_frames[3].loadFromFile("sprite/standy4l.png");
    nl_frames[4].loadFromFile("sprite/standy5l.png");
    nl_frames[5].loadFromFile("sprite/standy6l.png");
    nl_frames[6].loadFromFile("sprite/standy7l.png");
    nl_frames[7].loadFromFile("sprite/standy8l.png");
    nl_frames[8].loadFromFile("sprite/standy9l.png");
    nl_frames[9].loadFromFile("sprite/standy10l.png");
    nl_frames[10].loadFromFile("sprite/standy11l.png");
    nl_frames[11].loadFromFile("sprite/standy12l.png");
    nl_frames[12].loadFromFile("sprite/movey1l.png");
    nl_frames[13].loadFromFile("sprite/movey2l.png");
    nl_frames[14].loadFromFile("sprite/movey3l.png");
    nl_frames[15].loadFromFile("sprite/movey4l.png");
    nl_frames[16].loadFromFile("sprite/movey5l.png");
    nl_frames[17].loadFromFile("sprite/movey6l.png");
    nl_frames[18].loadFromFile("sprite/movey7l.png");
    nl_frames[19].loadFromFile("sprite/movey8l.png");
    nl_frames[20].loadFromFile("sprite/movey9l.png");
    nl_frames[21].loadFromFile("sprite/movey10l.png");
    nl_frames[22].loadFromFile("sprite/movey11l.png");
    nl_frames[23].loadFromFile("sprite/movey12l.png");
    nl_frames[24].loadFromFile("sprite/movey13l.png");
    nl_frames[25].loadFromFile("sprite/movey14l.png");
    nl_frames[26].loadFromFile("sprite/movey15l.png");
    nl_frames[27].loadFromFile("sprite/movey16l.png");
    nl_frames[28].loadFromFile("sprite/movey17l.png");
    nl_frames[29].loadFromFile("sprite/movey18l.png");
}
Enemy_2::Enemy_2(int x, int y, int vx, int vy, std::vector<std::vector<Building_block>> *all_the_blocks)
    : Object(x, y, vx, vy)
{
    set_motion_frames();
    all_blocks = all_the_blocks;
}
void Enemy_2::make_the_next_move()
{
    if (frame_counter % ENEMEIS_NORMALIZER == 0)
    {
        calculate_Vy_from_gravity();
        int x_pos = this->getPosition().x,
            new_x = x_pos + Vx * TIME_STEP;
        int y_pos = this->getPosition().y,
            new_y = y_pos + Vy * TIME_STEP;
        if (is_moving_valid(new_x, y_pos, *all_blocks) == MOVING_VALID && !recognize_edge())
        {
            make_act();
        }
        else
        {
            Vx = -Vx;
            make_act();
        }
        if (is_moving_valid(x_pos, new_y, *all_blocks) == MOVING_VALID)
            this->move(0, Vy * TIME_STEP);
        else
            Vy = 0;
        frame_counter = 0;
    }
    frame_counter++;
}

bool Enemy_2::recognize_edge()
{
    Enemy_2 fake_enemy = *this;
    fake_enemy.move(Vx * 5 * TIME_STEP, 0);
    fake_enemy.calculate_Vy_from_gravity();
    int x_pos = fake_enemy.getPosition().x;
    int y_pos = fake_enemy.getPosition().y,
        new_y = y_pos + Vy * TIME_STEP;
    if (is_moving_valid(x_pos, new_y, *all_blocks) == MOVING_VALID)
        return true;
    return false;
}

void Portal::set_motion_frames()
{
    portal_tex[0].loadFromFile("sprite/portalb.png");
    portal_tex[1].loadFromFile("sprite/portaly.png");
    setScale(1.25, 1.25);
}
Portal::Portal(int x, int y, int vx, int vy, std::vector<std::vector<Building_block>> *all_the_blocks)
    : Object(x, y, vx, vy)
{
    set_motion_frames();
    all_blocks = all_the_blocks;
}

void Kid::respawn_kid()
{
    status = TRAPPED;
    setPosition(first_location.first, first_location.second);
    reset_counters();
}