#include "Game.hh"
#include "environment.hh"
#include "object.hh"
#include <iostream>
#include <SFML/Graphics.hpp>
#include <string>
#include <vector>
#include <fstream>
#include <sstream>
using namespace std;
using namespace sf;

void Game_information::make_stars(std::pair<int, int> position)
{
    for (int j = 0; j < STARS_ROW_AND_COL_COUNT; j++)
        for (int i = 0; i < STARS_ROW_AND_COL_COUNT; i++)
        {
            Star new_star(position.first + i * (STAR_SIZE + GUTTER_SIZE),
                          position.second - j * (STAR_SIZE + GUTTER_SIZE), 0, 0, &all_blocks);
            all_stars.push_back(new_star);
        }
}

void Game_information::make_diamonds(std::pair<int, int> position)
{
    for (int j = 0; j < STARS_ROW_AND_COL_COUNT; j++)
        for (int i = 0; i < STARS_ROW_AND_COL_COUNT; i++)
        {
            Diamond new_diamond(position.first + i * (STAR_SIZE + GUTTER_SIZE),
                                position.second - j * (STAR_SIZE + GUTTER_SIZE), 0, 0, &all_blocks);
            all_diamonds.push_back(new_diamond);
        }
}

void Game_information::read_map_file()
{
    std::ifstream map_stream(MAP_NAME);
    if (!map_stream)
    {
        std::cerr << "map can't be loaded" << std::endl;
        abort();
    }
    std::string line;
    int line_number = 0;
    while (std::getline(map_stream, line))
    {
        std::vector<Building_block> new_row_block;
        int i = 0, block_counts = 0;
        while (true)
        {
            block_counts = new_row_block.size();
            while (i < line.size() && (i == 0 || line[i] == line[i - 1]))
                i++;
            if (line[i - 1] == '.')
            {
                for (int x = block_counts; x <= i / BLOCK_DOTS_COUNT; x++)
                    make_and_push_block(x, line_number, new_row_block, all_textures, GROUND_TEXTURE);
            }
            else if (line[i - 1] == '-')
                for (int x = block_counts; x <= i / BLOCK_DOTS_COUNT; x++)
                    make_and_push_block(x, line_number, new_row_block, all_textures, GRASS_TEXTURE);
            else
            {
                for (int x = block_counts; x <= i / BLOCK_DOTS_COUNT; x++)
                    make_and_push_block(x, line_number, new_row_block, all_textures, SKY_TEXTURE);

                if (line[i - 1] == 'P')
                {
                    Turtix the_turtix(find_equal_position(i, line_number).first,
                                      find_equal_position(i, line_number).second, 0, 0, &all_blocks);
                    turtix = the_turtix;
                }
                else if (line[i - 1] == '#')
                    this->make_stars(find_equal_position(i, line_number));
                else if (line[i - 1] == 'D')
                    this->make_diamonds(find_equal_position(i, line_number));
                else if (line[i - 1] == 'A')
                {
                    Kid new_kid(find_equal_position(i, line_number).first,
                                find_equal_position(i, line_number).second, THE_VX, 0, &all_blocks);
                    kids.push_back(new_kid);
                }
                else if (line[i - 1] == 'M')
                {
                    Enemy_1 new_enemy(find_equal_position(i, line_number).first,
                                      find_equal_position(i, line_number).second, THE_VX, 0, &all_blocks);
                    all_enemy1.push_back(new_enemy);
                }
                else if (line[i - 1] == 'E')
                {
                    Enemy_2 new_enemy(find_equal_position(i, line_number).first,
                                      find_equal_position(i, line_number).second, THE_VX, 0, &all_blocks);
                    all_enemy2.push_back(new_enemy);
                }

                else if (line[i - 1] == 'G')
                {
                    Portal new_portal(find_equal_position(i, line_number).first,
                                      find_equal_position(i, line_number).second, THE_VX, 0, &all_blocks);
                    portal = new_portal;
                    portal.set_the_texture();
                }
            }
            i++;
            if (i >= line.size())
                break;
        }
        all_blocks.push_back(new_row_block);
        line_number++;
    }
}

Game_information::Game_information(int JUNK)
{
    load_new_texture(GR_TEX_DIRECTORY, all_textures);
    load_new_texture(SKY_TEX_DIRECTORY, all_textures);
    load_new_texture(GRASS_TEX_DIRECTORY, all_textures);
    set_font();
    read_map_file();
}

void Game_information::move_view(sf::View &view, int row_count, int column_count)
{
    sf::Vector2f turtix_position = turtix.getPosition();
    sf::Vector2f current_view_pos = view.getCenter();

    if (turtix_position.y + HALF_SCREEN_HEIGHT * VIEW_SCALE / 2 <=
            ((row_count - NO_VISIBLE_BLOCKS_SIZE) * BLOCK_SIZE) &&
        turtix_position.y - HALF_SCREEN_HEIGHT * VIEW_SCALE / 2 >=
            (NO_VISIBLE_BLOCKS_SIZE * BLOCK_SIZE))
        view.setCenter(current_view_pos.x, turtix_position.y);
    current_view_pos = view.getCenter();

    if (turtix_position.x - HALF_SCREEN_LENGTH * VIEW_SCALE / 2 >=
            (NO_VISIBLE_BLOCKS_SIZE * BLOCK_SIZE) &&
        turtix_position.x + HALF_SCREEN_LENGTH * VIEW_SCALE / 2 <=
            ((column_count - NO_VISIBLE_BLOCKS_SIZE) * BLOCK_SIZE))
        view.setCenter(turtix_position.x, current_view_pos.y);
}

void Game_information::make_others_move()
{
    for (auto &x : all_enemy2)
        x.make_the_next_move();
    for (auto &x : all_enemy1)
        x.make_the_next_move();
    for (auto &x : kids)
        x.make_the_next_move();
}

void Game_information::draw_everything(sf::RenderWindow &window, const sf::View &view)
{

    window.draw(portal);
    if (turtix.still_exists())
        window.draw(turtix);
    for (auto &x : all_enemy1)
        if (x.still_exists())
            window.draw(x);
    for (auto &x : all_enemy2)
        if (x.still_exists())
            window.draw(x);
    for (auto &x : all_stars)
        if (x.still_exists())
            window.draw(x);
    for (auto &x : all_diamonds)
        if (x.still_exists())
            window.draw(x);
    for (auto &x : kids)
        if (x.still_exists())
            window.draw(x);

    draw_total_points(window, view);
    draw_life_count(window, view);
}

void Game_information::tik(int last_move_x, int last_move_y, sf::RenderWindow &window, const sf::View &view, int &game_status)
{
    if (turtix.get_life_count() <= 0)
        game_status = MAIN_MENU;
    else if (kids_count == 0)
        game_status = MAIN_MENU;
    else
    {
        make_others_move();
        check_objects_collisions(last_move_y);
        examinate_turtix(last_move_x, last_move_y);
        check_the_explosions();
        change_the_textures();
        draw_everything(window, view);
    }
}

void Game_information::draw_total_points(sf::RenderWindow &window, const sf::View &view)
{
    stringstream point_stream;
    point_stream << "TOTAL_POINT : " << point;
    string point_string;
    getline(point_stream, point_string);
    sf::Text point_text;
    point_text.setFont(arial);
    point_text.setString(point_string);
    point_text.setCharacterSize(30);
    point_text.setFillColor(sf::Color::Black);
    point_text.setPosition(view.getCenter().x - HALF_SCREEN_LENGTH * VIEW_SCALE / 2 + BLOCK_SIZE,
                           view.getCenter().y - HALF_SCREEN_HEIGHT * VIEW_SCALE / 2 + BLOCK_SIZE);

    window.draw(point_text);
}

void Game_information::draw_life_count(sf::RenderWindow &window, const sf::View &view)
{
    stringstream life_count_stream;
    life_count_stream << "LIFE_COUNT : " << turtix.get_life_count();
    string life_count_string;
    getline(life_count_stream, life_count_string);
    sf::Text life_count_text;
    life_count_text.setFont(arial);
    life_count_text.setString(life_count_string);
    life_count_text.setCharacterSize(30);
    life_count_text.setFillColor(sf::Color::Black);
    life_count_text.setPosition(view.getCenter().x - HALF_SCREEN_LENGTH * VIEW_SCALE / 2 + BLOCK_SIZE,
                                view.getCenter().y - HALF_SCREEN_HEIGHT * VIEW_SCALE / 2 + 2 * BLOCK_SIZE);

    window.draw(life_count_text);
}

void Game_information::change_the_textures()
{
    for (auto &x : all_stars)
        x.change_texture();
    for (auto &x : all_diamonds)
        x.change_texture();
}

void Game_information::check_the_explosions()
{
    for (auto &x : all_diamonds)
        if (x.is_colision_happend(this->turtix))
        {
            point += DIAMONDS_POINT;
            x.expulsion();
        }
    for (auto &x : all_stars)
        if (x.is_colision_happend(this->turtix))
        {
            point += STARS_POINT;
            x.expulsion();
        }
}

void Game_information::examinate_turtix(int last_move_x, int last_move_y)
{
    if (last_move_y == UP && !turtix.jumping)
    {
        turtix.set_Vy(THE_VY);
    }
    if (last_move_x == RIGHT)
        this->turtix.set_Vx(THE_VX);
    else if (last_move_x == LEFT)
        this->turtix.set_Vx(-THE_VX);
    if (last_move_x == NOTHING)
    {
        this->turtix.set_Vx(0);
        turtix.reset_counters();
        turtix.stand();
    }
    this->turtix.make_the_next_move();
}

void Game_information::check_objects_collisions(int &last_move_y)
{
    Turtix fake_turtix = turtix;
    fake_turtix.move_turtix_x();
    if (turtix.get_status() == NORMAL)
    {
        for (auto &x : all_enemy1)
            if (x.still_exists() && x.get_status() == NORMAL && fake_turtix.getGlobalBounds().intersects(x.getGlobalBounds()))
            {
                turtix.hit();
                return;
            }
        for (auto &x : all_enemy2)
            if (x.still_exists() && (x.get_status() == SAFE || x.get_status() == DANGEROUS) &&
                fake_turtix.getGlobalBounds().intersects(x.getGlobalBounds()))
            {
                turtix.hit();
                return;
            }
        for (auto &x : kids)
            if (x.still_exists() && x.get_status() == TRAPPED && fake_turtix.getGlobalBounds().intersects(x.getGlobalBounds()))
            {
                return;
            }
        fake_turtix.move_turtix_y();
        for (auto &x : all_enemy1)
            if (x.still_exists() && x.get_status() == NORMAL && fake_turtix.getGlobalBounds().intersects(x.getGlobalBounds()))
            {
                turtix.jumping = false;
                last_move_y = UP;
                x.hit();
            }
        for (auto &x : all_enemy2)
            if (x.still_exists() && x.get_status() == SAFE && fake_turtix.getGlobalBounds().intersects(x.getGlobalBounds()))
            {
                turtix.jumping = false;
                last_move_y = UP;
                x.hit();
            }
            else if (x.still_exists() && x.get_status() == DANGEROUS && fake_turtix.getGlobalBounds().intersects(x.getGlobalBounds()))
            {
                turtix.jumping = false;
                last_move_y = UP;
                turtix.hit();
                return;
            }
        for (auto &x : kids)
            if (x.still_exists() && x.get_status() == TRAPPED && fake_turtix.getGlobalBounds().intersects(x.getGlobalBounds()))
            {
                turtix.jumping = false;
                last_move_y = UP;
                x.release();
            }
        for (auto &x : kids)
            if (x.still_exists() && x.get_status() == FREE && x.getGlobalBounds().intersects(portal.getGlobalBounds()))
            {
                x.expulsion();
                kids_count--;
            }
        for (auto &x : kids)
            for (auto &y : all_enemy1)
                if (x.still_exists() && x.get_status() == FREE && y.still_exists() && x.getGlobalBounds().intersects(y.getGlobalBounds()))
                    x.respawn_kid();
        for (auto &x : kids)
            for (auto &y : all_enemy2)
                if (x.still_exists() && x.get_status() == FREE && y.still_exists() && x.getGlobalBounds().intersects(y.getGlobalBounds()))
                    x.respawn_kid();
    }
}

sf::RectangleShape make_background(int column_counts, int row_counts)
{
    Vector2f background_size(column_counts * BLOCK_SIZE, row_counts * BLOCK_SIZE);
    RectangleShape background(background_size);
    background.setFillColor(Color::Cyan);
    return background;
}

void load_needed_texture(std::vector<sf::Texture> &all_textures)
{
    load_new_texture(MENU_TEX_DIR, all_textures);
    load_new_texture(START_TEX_DIR, all_textures);
    load_new_texture(RESUME_TEX_DIR, all_textures);
    load_new_texture(GAME_OVER_TEX_DIR, all_textures);
    load_new_texture(EXIT_TEX_DIR, all_textures);
    load_new_texture(MAIN_MENU_TEX_DIR, all_textures);
}

sf::Sprite make_sprite(std::vector<sf::Texture> &all_textures, int x_offset, int y_offset, int texture_name)
{
    Sprite new_sprite(all_textures[texture_name]);
    new_sprite.setOrigin(new_sprite.getGlobalBounds().width / 2,
                         new_sprite.getGlobalBounds().height / 2);
    new_sprite.setPosition(HALF_SCREEN_LENGTH + BLOCK_SIZE * x_offset, HALF_SCREEN_HEIGHT + y_offset * BLOCK_SIZE);
    return new_sprite;
}

