#ifndef _ENVO
#define _ENVO

#include <iostream>
#include <SFML/Graphics.hpp>
#include <string>
#include <vector>
#include <fstream>

const std::string MAP_NAME = "pap.txt";
const std::string GR_TEX_DIRECTORY = "sprite/ground_block.png";
const std::string SKY_TEX_DIRECTORY = "sprite/sky.png";
const std::string GRASS_TEX_DIRECTORY = "sprite/grass.png";
const std::string MENU_TEX_DIR = "sprite/menu_game.png";
const int JUNK = -1;
const int ENVO_TEXTUER_SIZE = 50;
const int BLOCK_SIZE = 50;
const int BLOCK_DOTS_COUNT = 2;
const int NO_VISIBLE_BLOCKS_SIZE = 2;
const int CORNERS_COUNT = 4;
const int HALF_SCREEN_HEIGHT = 400;
const int HALF_SCREEN_LENGTH = 500;

enum textures
{
    GROUND_TEXTURE,
    SKY_TEXTURE,
    GRASS_TEXTURE,
    MENU_TEXTURE,
    START_TEXTURE,
    RESUME_TEXTURE,
    GAMEOVER_TEXTURE,
    EXIT_TEXTURE,
    MAIN_MENU_TEXTURE
};

std::vector<std::pair<int, int>> find_corners(int x_offset, int y_ofsset, int base_x, int base_y);
class Environmental_element
{
public:
    Environmental_element(int init_x, int init_y, int init_height, int init_width)
        : x(init_x), y(init_y), height(init_height), width(init_width),
          corners(find_corners(width, height, x, y)) {}

protected:
    int x;
    int y;
    int height;
    int width;
    int Vx;
    int Vy;
    int gravity = 10;
    std::vector<std::pair<int, int>> corners;
};

class Building_block : public Environmental_element, public sf::Drawable
{
public:
    Building_block(int init_x, int init_y, int texture_name, int init_height,
                   int init_width, std::vector<sf::Texture> texture);
    int get_x() { return x; }
    int get_texture_name()
    {
        return block_texture_name;
    }
    void set_texture(int texture_name, std::vector<sf::Texture> all_textures)
    {
        block_texture = all_textures[texture_name];
        block_texture_name = texture_name;
    }

protected:
    virtual void draw(sf::RenderTarget &window, sf::RenderStates states) const;
    void set_vertex_position();
    void set_vertex_coords();
    int block_texture_name;
    sf::VertexArray block_vertices;
    sf::Sprite block_sprite;
    sf::Texture block_texture;
};

void make_and_push_block(int x, int y, std::vector<Building_block> &all_blocks,
                         std::vector<sf::Texture> all_textures, int texture_name);
void load_new_texture(std::string texture_name, std::vector<sf::Texture> &all_textures);
void set_draw_area(int turtix_x, int turtix_y, sf::RenderWindow &window, std::vector<std::vector<Building_block>> all_blocks);

#endif